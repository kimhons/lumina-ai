# Lumina AI AWS EKS Deployment Package

This package contains all the necessary configurations and scripts to deploy Lumina AI to AWS EKS.

## Contents

- `kubernetes/` - Kubernetes configuration files
  - `base/` - Base Kubernetes configurations
  - `overlays/` - Environment-specific overlays (dev, staging, prod)
  - `monitoring/` - Prometheus and Grafana configurations
  - `security/` - Security-related configurations

- `ci-cd/` - CI/CD pipeline configurations
  - `Jenkinsfile` - Jenkins pipeline configuration
  - `github-actions/` - GitHub Actions workflow configurations

- `deploy.sh` - Main deployment script
- `validate-deployment.sh` - Validation script for Kubernetes configurations

- `docs/` - Documentation
  - `lumina_ai_eks_deployment_guide.md` - Comprehensive deployment guide
  - `lumina_ai_cicd_pipeline_documentation.md` - CI/CD pipeline documentation
  - `lumina_ai_troubleshooting_guide.md` - Troubleshooting guide

## Quick Start

1. Configure AWS CLI with appropriate credentials
2. Run the validation script:
   ```
   ./validate-deployment.sh
   ```
3. Deploy to your desired environment:
   ```
   ./deploy.sh --environment dev|staging|prod
   ```

## Advanced Usage

See `./deploy.sh --help` for additional deployment options.

For detailed instructions, refer to the documentation in the `docs/` directory.
