# Lumina AI Deployment Checklist

Use this checklist to ensure a successful deployment of Lumina AI to AWS EKS.

## Pre-Deployment

- [ ] AWS account with appropriate permissions is available
- [ ] AWS CLI is installed and configured
- [ ] kubectl is installed and configured
- [ ] EKS cluster is created and running
- [ ] ECR repositories are created for all services
- [ ] Database (AWS Aurora PostgreSQL) is provisioned
- [ ] Secrets are configured in AWS Secrets Manager or as Kubernetes Secrets

## Validation

- [ ] Run `./validate-deployment.sh` to validate Kubernetes configurations
- [ ] Verify all validation checks pass without errors
- [ ] Address any warnings identified during validation

## Deployment

- [ ] Select the appropriate environment (dev, staging, prod)
- [ ] Run `./deploy.sh` with appropriate parameters
- [ ] Verify all deployments are successful
- [ ] Check that all pods are running and healthy
- [ ] Verify ingress configuration and DNS settings

## Post-Deployment

- [ ] Test application functionality
- [ ] Verify monitoring is working (Prometheus and Grafana)
- [ ] Check that alerts are properly configured
- [ ] Verify backup CronJob is running
- [ ] Document any issues or observations for future deployments
