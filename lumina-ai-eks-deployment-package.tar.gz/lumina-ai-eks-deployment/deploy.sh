#!/bin/bash

# Deployment script for Lumina AI on AWS EKS
# This script automates the deployment process for Lumina AI

set -e

# Default values
ENVIRONMENT="dev"
REGION="us-west-2"
CLUSTER_NAME="lumina-ai-cluster"
SKIP_VALIDATION=false
SKIP_BUILD=false

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    -e|--environment)
      ENVIRONMENT="$2"
      shift
      shift
      ;;
    -r|--region)
      REGION="$2"
      shift
      shift
      ;;
    -c|--cluster)
      CLUSTER_NAME="$2"
      shift
      shift
      ;;
    --skip-validation)
      SKIP_VALIDATION=true
      shift
      ;;
    --skip-build)
      SKIP_BUILD=true
      shift
      ;;
    -h|--help)
      echo "Usage: $0 [options]"
      echo "Options:"
      echo "  -e, --environment ENV    Deployment environment (dev, staging, prod) [default: dev]"
      echo "  -r, --region REGION      AWS region [default: us-west-2]"
      echo "  -c, --cluster CLUSTER    EKS cluster name [default: lumina-ai-cluster]"
      echo "  --skip-validation        Skip validation step"
      echo "  --skip-build             Skip Docker build step"
      echo "  -h, --help               Show this help message"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

echo "Deploying Lumina AI to AWS EKS"
echo "=============================="
echo "Environment: $ENVIRONMENT"
echo "AWS Region: $REGION"
echo "EKS Cluster: $CLUSTER_NAME"
echo ""

# Validate configuration if not skipped
if [ "$SKIP_VALIDATION" = false ]; then
  echo "Validating deployment configuration..."
  ./validate-deployment.sh
  
  # Check if validation was successful
  if [ $? -ne 0 ]; then
    echo "Validation failed. Please fix the issues before deploying."
    exit 1
  fi
else
  echo "Skipping validation step..."
fi

# Configure AWS CLI
echo "Configuring AWS CLI..."
aws configure set region $REGION

# Update kubeconfig for EKS cluster
echo "Updating kubeconfig for EKS cluster..."
aws eks update-kubeconfig --name $CLUSTER_NAME --region $REGION

# Build and push Docker images if not skipped
if [ "$SKIP_BUILD" = false ]; then
  echo "Building and pushing Docker images..."
  
  # Login to ECR
  echo "Logging in to Amazon ECR..."
  aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin $(aws sts get-caller-identity --query Account --output text).dkr.ecr.$REGION.amazonaws.com
  
  # Build and push images
  SERVICES=("ui-service" "deployment-service" "provider-service" "governance-service" "enduser-service" "marketing-website")
  
  for service in "${SERVICES[@]}"; do
    echo "Building and pushing $service..."
    
    # Determine build context based on service
    if [ "$service" = "ui-service" ]; then
      CONTEXT="./lumina-ai/ui"
    elif [ "$service" = "enduser-service" ]; then
      CONTEXT="./lumina-ai/ui/enduser"
    elif [ "$service" = "marketing-website" ]; then
      CONTEXT="./lumina-ai-website"
    else
      CONTEXT="./lumina-ai/microservices/$service"
    fi
    
    # Build and push Docker image
    docker build -t lumina-ai/$service:latest $CONTEXT
    docker tag lumina-ai/$service:latest $(aws sts get-caller-identity --query Account --output text).dkr.ecr.$REGION.amazonaws.com/lumina-ai/$service:latest
    docker push $(aws sts get-caller-identity --query Account --output text).dkr.ecr.$REGION.amazonaws.com/lumina-ai/$service:latest
  done
else
  echo "Skipping Docker build step..."
fi

# Deploy using kustomize
echo "Deploying Lumina AI to $ENVIRONMENT environment..."
kubectl apply -k ./kubernetes/overlays/$ENVIRONMENT

# Wait for deployments to be ready
echo "Waiting for deployments to be ready..."
NAMESPACE=$([ "$ENVIRONMENT" = "prod" ] && echo "lumina-ai" || echo "lumina-ai-$ENVIRONMENT")
kubectl rollout status deployment/ui-service -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/deployment-service -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/provider-service -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/governance-service -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/enduser-service -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/marketing-website -n $NAMESPACE --timeout=300s

# Get service endpoints
echo "Deployment complete! Service endpoints:"
kubectl get ingress -n $NAMESPACE

echo ""
echo "Lumina AI has been successfully deployed to AWS EKS!"
echo "===================================================="
