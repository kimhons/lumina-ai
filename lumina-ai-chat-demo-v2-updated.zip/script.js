// Lumina AI Chat Interface - Interactive Features

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message');
    const emptyState = document.getElementById('empty-state');
    const messagesContainer = document.getElementById('messages-container');
    const memoryToggle = document.getElementById('memory-toggle');
    const thinkingToggle = document.getElementById('thinking-toggle');
    const tasksToggle = document.getElementById('tasks-toggle');
    const operatorToggle = document.getElementById('operator-toggle');
    const memoryPanel = document.getElementById('memory-panel');
    const operatorWindow = document.getElementById('operator-window');
    const closeMemory = document.getElementById('close-memory');
    const closeOperator = document.getElementById('close-operator');
    const minimizeOperator = document.getElementById('minimize-operator');
    const suggestionCards = document.querySelectorAll('.suggestion-card');
    const acceptTaskButton = document.getElementById('accept-task');
    const modifyTaskButton = document.getElementById('modify-task');
    const dismissTaskButton = document.getElementById('dismiss-task');
    const voiceInputButton = document.getElementById('voice-input');
    const searchButton = document.getElementById('search-button');
    const deepResearchButton = document.getElementById('deep-research');
    const operatorTabs = document.querySelectorAll('.operator-tab');
    const projectHeaders = document.querySelectorAll('.project-header');
    const addProjectButton = document.querySelector('.add-project-button');
    
    // Initialize the interface
    initializeInterface();
    
    // Add event listeners
    addEventListeners();
    
    // Functions
    function initializeInterface() {
        // Focus on the message input
        messageInput.focus();
        
        // Show empty state by default
        emptyState.style.display = 'flex';
        messagesContainer.style.display = 'none';
    }
    
    function addEventListeners() {
        // Send message on button click
        if (sendButton) {
            sendButton.addEventListener('click', handleSendMessage);
        }
        
        // Send message on Enter key (without Shift)
        if (messageInput) {
            messageInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                }
            });
            
            // Auto-resize textarea
            messageInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
        }
        
        // Toggle memory panel
        if (memoryToggle) {
            memoryToggle.addEventListener('click', function() {
                memoryPanel.classList.toggle('active');
                // Close operator window if open
                operatorWindow.classList.remove('active');
            });
        }
        
        // Close memory panel
        if (closeMemory) {
            closeMemory.addEventListener('click', function() {
                memoryPanel.classList.remove('active');
            });
        }
        
        // Toggle operator window
        if (operatorToggle) {
            operatorToggle.addEventListener('click', function() {
                operatorWindow.classList.toggle('active');
                // Close memory panel if open
                memoryPanel.classList.remove('active');
            });
        }
        
        // Close operator window
        if (closeOperator) {
            closeOperator.addEventListener('click', function() {
                operatorWindow.classList.remove('active');
            });
        }
        
        // Minimize operator window
        if (minimizeOperator) {
            minimizeOperator.addEventListener('click', function() {
                operatorWindow.classList.remove('active');
                showNotification('Operator window minimized');
            });
        }
        
        // Toggle thinking display
        if (thinkingToggle) {
            thinkingToggle.addEventListener('click', function() {
                const thinkingDisplay = document.querySelector('.thinking-display');
                if (thinkingDisplay) {
                    thinkingDisplay.classList.toggle('hidden');
                } else {
                    showNotification('Visual thinking is not available for this conversation yet');
                }
            });
        }
        
        // Toggle tasks panel
        if (tasksToggle) {
            tasksToggle.addEventListener('click', function() {
                const taskStatus = document.querySelector('.task-status');
                if (taskStatus) {
                    taskStatus.classList.toggle('hidden');
                } else {
                    showNotification('No active tasks for this conversation');
                }
            });
        }
        
        // Handle suggestion cards
        if (suggestionCards) {
            suggestionCards.forEach(card => {
                card.addEventListener('click', function() {
                    const topic = card.querySelector('h3').textContent;
                    messageInput.value = `Help me with ${topic.toLowerCase()}`;
                    handleSendMessage();
                });
            });
        }
        
        // Handle task buttons
        if (acceptTaskButton) {
            acceptTaskButton.addEventListener('click', function() {
                const taskSuggestion = document.querySelector('.task-suggestion');
                if (taskSuggestion) {
                    taskSuggestion.classList.add('hidden');
                    showNotification('Task accepted and started');
                }
            });
        }
        
        if (modifyTaskButton) {
            modifyTaskButton.addEventListener('click', function() {
                showNotification('Task modification dialog would appear here');
            });
        }
        
        if (dismissTaskButton) {
            dismissTaskButton.addEventListener('click', function() {
                const taskSuggestion = document.querySelector('.task-suggestion');
                if (taskSuggestion) {
                    taskSuggestion.classList.add('hidden');
                    showNotification('Task suggestion dismissed');
                }
            });
        }
        
        // Handle voice input
        if (voiceInputButton) {
            voiceInputButton.addEventListener('click', function() {
                showNotification('Voice input activated');
                // Simulate voice input after a delay
                setTimeout(() => {
                    messageInput.value = 'Tell me more about renewable energy in emerging markets';
                    showNotification('Voice input captured');
                }, 2000);
            });
        }
        
        // Handle search button
        if (searchButton) {
            searchButton.addEventListener('click', function() {
                showNotification('Search activated');
                messageInput.value = 'Search: renewable energy trends';
                messageInput.focus();
            });
        }
        
        // Handle deep research button
        if (deepResearchButton) {
            deepResearchButton.addEventListener('click', function() {
                showNotification('Deep research mode activated');
                messageInput.value = 'Conduct deep research on renewable energy market growth';
                messageInput.focus();
            });
        }
        
        // Handle operator tabs
        if (operatorTabs) {
            operatorTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remove active class from all tabs
                    operatorTabs.forEach(t => t.classList.remove('active'));
                    // Add active class to clicked tab
                    tab.classList.add('active');
                    
                    // Hide all tab content
                    const tabContents = document.querySelectorAll('.operator-tab-content');
                    tabContents.forEach(content => content.style.display = 'none');
                    
                    // Show selected tab content
                    const tabId = tab.getAttribute('data-tab');
                    const selectedContent = document.getElementById(`${tabId}-tab`);
                    if (selectedContent) {
                        selectedContent.style.display = 'block';
                    }
                });
            });
        }
        
        // Handle project headers (expand/collapse)
        if (projectHeaders) {
            projectHeaders.forEach(header => {
                header.addEventListener('click', function() {
                    const projectItems = this.nextElementSibling;
                    const toggleIcon = this.querySelector('.project-toggle');
                    
                    if (projectItems.style.display === 'none') {
                        projectItems.style.display = 'block';
                        toggleIcon.textContent = 'expand_more';
                    } else {
                        projectItems.style.display = 'none';
                        toggleIcon.textContent = 'chevron_right';
                    }
                });
            });
        }
        
        // Handle add project button
        if (addProjectButton) {
            addProjectButton.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent event bubbling
                showProjectDialog();
            });
        }
    }
    
    function showProjectDialog() {
        // Create dialog element
        const dialog = document.createElement('div');
        dialog.className = 'dialog-overlay';
        
        dialog.innerHTML = `
            <div class="dialog">
                <div class="dialog-header">
                    <h3>Create New Project</h3>
                    <button class="icon-button" id="close-dialog">
                        <span class="material-icons-round">close</span>
                    </button>
                </div>
                <div class="dialog-content">
                    <div class="form-group">
                        <label for="project-name">Project Name</label>
                        <input type="text" id="project-name" placeholder="Enter project name">
                    </div>
                    <div class="form-group">
                        <label for="project-description">Description (optional)</label>
                        <textarea id="project-description" placeholder="Enter project description"></textarea>
                    </div>
                </div>
                <div class="dialog-footer">
                    <button class="secondary-button" id="cancel-project">Cancel</button>
                    <button class="primary-button" id="create-project">Create Project</button>
                </div>
            </div>
        `;
        
        // Add to the DOM
        document.body.appendChild(dialog);
        
        // Add event listeners
        const closeDialog = document.getElementById('close-dialog');
        const cancelProject = document.getElementById('cancel-project');
        const createProject = document.getElementById('create-project');
        const projectNameInput = document.getElementById('project-name');
        
        closeDialog.addEventListener('click', () => dialog.remove());
        cancelProject.addEventListener('click', () => dialog.remove());
        
        createProject.addEventListener('click', () => {
            const projectName = projectNameInput.value.trim();
            if (projectName) {
                createNewProject(projectName);
                dialog.remove();
            } else {
                projectNameInput.classList.add('error');
                setTimeout(() => projectNameInput.classList.remove('error'), 1000);
            }
        });
        
        // Focus on input
        projectNameInput.focus();
        
        // Add dialog styles
        const style = document.createElement('style');
        style.textContent = `
            .dialog-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
            }
            
            .dialog {
                background-color: #202123;
                border-radius: 8px;
                width: 400px;
                max-width: 90%;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                display: flex;
                flex-direction: column;
            }
            
            .dialog-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 16px;
                border-bottom: 1px solid #4D4D4F;
            }
            
            .dialog-header h3 {
                font-size: 16px;
                font-weight: 600;
            }
            
            .dialog-content {
                padding: 16px;
                display: flex;
                flex-direction: column;
                gap: 16px;
            }
            
            .form-group {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            
            .form-group label {
                font-size: 14px;
                color: #ACACBE;
            }
            
            .form-group input, .form-group textarea {
                padding: 10px 12px;
                border: 1px solid #4D4D4F;
                border-radius: 6px;
                background-color: #40414F;
                color: #ECECF1;
                font-size: 14px;
                font-family: inherit;
            }
            
            .form-group textarea {
                min-height: 80px;
                resize: vertical;
            }
            
            .form-group input:focus, .form-group textarea:focus {
                outline: none;
                border-color: #10A37F;
            }
            
            .form-group input.error, .form-group textarea.error {
                border-color: #E53935;
            }
            
            .dialog-footer {
                padding: 16px;
                display: flex;
                justify-content: flex-end;
                gap: 12px;
                border-top: 1px solid #4D4D4F;
            }
        `;
        
        document.head.appendChild(style);
    }
    
    function createNewProject(projectName) {
        // Create new project group
        const projectsSection = document.querySelector('.projects-section .section-items');
        
        const projectGroup = document.createElement('div');
        projectGroup.className = 'project-group';
        
        projectGroup.innerHTML = `
            <div class="project-header">
                <span class="project-title">${projectName}</span>
                <span class="project-toggle material-icons-round">expand_more</span>
            </div>
            <div class="project-items">
                <div class="sidebar-item">
                    <span class="item-text">Initial Planning v1</span>
                </div>
            </div>
        `;
        
        // Add to the DOM
        projectsSection.prepend(projectGroup);
        
        // Add event listener to the new project header
        const projectHeader = projectGroup.querySelector('.project-header');
        projectHeader.addEventListener('click', function() {
            const projectItems = this.nextElementSibling;
            const toggleIcon = this.querySelector('.project-toggle');
            
            if (projectItems.style.display === 'none') {
                projectItems.style.display = 'block';
                toggleIcon.textContent = 'expand_more';
            } else {
                projectItems.style.display = 'none';
                toggleIcon.textContent = 'chevron_right';
            }
        });
        
        showNotification(`Project "${projectName}" created`);
    }
    
    function handleSendMessage() {
        const messageText = messageInput.value.trim();
        if (!messageText) return;
        
        // Hide empty state and show messages container
        emptyState.style.display = 'none';
        messagesContainer.style.display = 'block';
        
        // Create a new message group for the user message
        const messageGroup = document.createElement('div');
        messageGroup.className = 'message-group';
        
        // Create the user message
        const userMessage = document.createElement('div');
        userMessage.className = 'message user-message';
        userMessage.innerHTML = `
            <div class="message-content">
                <p>${messageText}</p>
            </div>
        `;
        
        // Add the user message to the group
        messageGroup.appendChild(userMessage);
        
        // Add the message group to the container
        messagesContainer.appendChild(messageGroup);
        
        // Clear the input
        messageInput.value = '';
        messageInput.style.height = 'auto';
        
        // Scroll to the bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Update operator window with user message
        addOperatorLogEntry('OBSERVATION', `User message: "${messageText}"`);
        
        // Simulate assistant response after a delay
        setTimeout(() => {
            // Add thinking process to operator window
            addOperatorLogEntry('THOUGHT', 'Processing user request...');
            addOperatorLogEntry('PLAN', 'Generating appropriate response');
            addOperatorLogEntry('ACTION', 'Retrieving relevant information');
            
            // Create a new message group for the assistant response
            const assistantGroup = document.createElement('div');
            assistantGroup.className = 'message-group';
            
            // Create the assistant message
            const assistantMessage = document.createElement('div');
            assistantMessage.className = 'message assistant-message';
            
            // Generate response based on user message
            const responseText = generateResponse(messageText);
            
            assistantMessage.innerHTML = `
                <div class="message-content">
                    <p>${responseText}</p>
                </div>
            `;
            
            // Add the assistant message to the group
            assistantGroup.appendChild(assistantMessage);
            
            // Add the message group to the container
            messagesContainer.appendChild(assistantGroup);
            
            // Scroll to the bottom
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // Update context indicator
            updateContextIndicator(10); // Increase by 10%
            
            // Add result to operator window
            addOperatorLogEntry('RESULT', 'Response generated and displayed to user');
        }, 1000);
    }
    
    function addOperatorLogEntry(type, message) {
        const operatorLog = document.querySelector('.operator-log');
        if (!operatorLog) return;
        
        // Remove active class from current entry if exists
        const currentActive = operatorLog.querySelector('.log-entry.active');
        if (currentActive) {
            currentActive.classList.remove('active');
        }
        
        // Create new log entry
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';
        if (type === 'CURRENT') {
            logEntry.classList.add('active');
        }
        
        // Get current time
        const now = new Date();
        const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
        
        logEntry.innerHTML = `
            <span class="log-time">${timeString}</span>
            <span class="log-type">${type}</span>
            <span class="log-message">${message}</span>
        `;
        
        // Add to the log
        operatorLog.appendChild(logEntry);
        
        // Scroll to the bottom
        operatorLog.scrollTop = operatorLog.scrollHeight;
    }
    
    function generateResponse(userMessage) {
        // Simple response generation based on user message
        const lowerMessage = userMessage.toLowerCase();
        
        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return 'Hello! How can I help you today?';
        } else if (lowerMessage.includes('renewable energy')) {
            return 'Renewable energy is a rapidly growing sector globally. Would you like me to analyze specific trends or provide information about particular technologies like solar or wind power?';
        } else if (lowerMessage.includes('search:')) {
            return 'I\'ve searched for information on your query. Would you like me to compile the results into a structured report or provide a brief summary?';
        } else if (lowerMessage.includes('deep research')) {
            return 'I\'ll conduct comprehensive research on this topic, analyzing multiple sources and compiling detailed information. This may take a few moments. Would you like me to break this down into an autonomous task?';
        } else if (lowerMessage.includes('project')) {
            return 'I can help you manage your project. Would you like me to create a new conversation within this project? I can label it with an appropriate version number based on the content.';
        } else {
            return `I understand you're interested in "${userMessage}". How would you like me to help with this? I can provide information, create content, analyze data, or work on this as an autonomous task.`;
        }
    }
    
    function updateContextIndicator(increase) {
        const contextFill = document.querySelector('.context-fill');
        const contextText = document.querySelector('.context-text');
        
        if (contextFill && contextText) {
            // Get current width as percentage
            const currentWidth = parseFloat(contextFill.style.width) || 65;
            const newWidth = Math.min(currentWidth + increase, 100);
            
            // Update the fill width
            contextFill.style.width = `${newWidth}%`;
            
            // Update the text
            contextText.textContent = `Context: ${Math.round(newWidth)}% used`;
            
            // Change color based on percentage
            if (newWidth > 90) {
                contextFill.style.backgroundColor = '#E53935'; // Red
                showNotification('Warning: Context limit approaching');
            } else if (newWidth > 75) {
                contextFill.style.backgroundColor = '#FF9800'; // Orange
            }
        }
    }
    
    function showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        // Add to the DOM
        document.body.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => {
            notification.classList.add('active');
        }, 10);
        
        // Remove after delay
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // Add notification styles
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #202123;
            color: #ECECF1;
            padding: 12px 16px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.3s, transform 0.3s;
            font-size: 14px;
            border: 1px solid #4D4D4F;
        }
        
        .notification.active {
            opacity: 1;
            transform: translateY(0);
        }
    `;
    
    document.head.appendChild(style);
});
