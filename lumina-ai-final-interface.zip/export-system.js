/**
 * Lumina AI Export System
 * 
 * This module provides functionality for exporting projects created in Lumina AI
 * to various formats based on project type, with customization options and
 * deployment capabilities.
 */

class ExportSystem {
  constructor(options = {}) {
    // Default configuration
    this.config = {
      containerId: 'export-wizard',
      overlayId: 'export-overlay',
      progressId: 'export-progress',
      successId: 'export-success',
      closeButtonId: 'close-wizard',
      nextButtonId: 'wizard-next',
      backButtonId: 'wizard-back',
      projectTypeSelector: '.project-type-option',
      exportGoalSelector: '.export-goal-option',
      formatSelector: '.format-option',
      autoDetectProjectType: true,
      enableDeployment: true,
      ...options
    };
    
    // State
    this.state = {
      currentStep: 1,
      totalSteps: 5,
      projectType: null,
      projectName: '',
      projectFramework: '',
      exportGoal: null,
      selectedFormats: [],
      customOptions: {},
      isExporting: false,
      exportProgress: 0,
      exportResults: [],
      currentContent: {
        html: '',
        css: '',
        js: '',
        assets: []
      }
    };
    
    // Project type definitions
    this.projectTypes = {
      website: {
        name: 'Website',
        icon: 'language',
        description: 'Static or dynamic website',
        formats: ['source', 'static-site', 'deployment', 'optimized']
      },
      mobileApp: {
        name: 'Mobile App',
        icon: 'smartphone',
        description: 'iOS or Android application',
        formats: ['source', 'android-apk', 'ios-ipa', 'app-store']
      },
      dataViz: {
        name: 'Data Visualization',
        icon: 'bar_chart',
        description: 'Charts, graphs, and dashboards',
        formats: ['static-image', 'interactive', 'embed', 'data-export']
      },
      document: {
        name: 'Document',
        icon: 'description',
        description: 'Book, report, or article',
        formats: ['pdf', 'epub', 'print', 'web']
      },
      api: {
        name: 'API',
        icon: 'api',
        description: 'Backend service or API',
        formats: ['source', 'docker', 'serverless', 'documentation']
      },
      code: {
        name: 'Other Code',
        icon: 'code',
        description: 'Scripts, algorithms, etc.',
        formats: ['source', 'executable', 'library', 'documentation']
      }
    };
    
    // Export goals
    this.exportGoals = {
      development: {
        name: 'Continue Development',
        icon: 'code',
        description: 'Export code for further development'
      },
      testing: {
        name: 'Testing & Review',
        icon: 'bug_report',
        description: 'Share with others for testing and feedback'
      },
      deployment: {
        name: 'Production Deployment',
        icon: 'rocket_launch',
        description: 'Deploy to production environment'
      },
      presentation: {
        name: 'Presentation',
        icon: 'slideshow',
        description: 'Create materials for stakeholder presentation'
      }
    };
    
    // Format definitions
    this.formatDefinitions = {
      // Website formats
      'source': {
        name: 'Source Code Package',
        icon: 'folder_zip',
        description: 'Complete project files as ZIP archive',
        projectTypes: ['website', 'mobileApp', 'api', 'code'],
        fileExtension: '.zip'
      },
      'static-site': {
        name: 'Static Site Deployment',
        icon: 'public',
        description: 'Deploy to GitHub Pages, Netlify, or Vercel',
        projectTypes: ['website'],
        requiresDeployment: true
      },
      'deployment': {
        name: 'Server Configuration',
        icon: 'dns',
        description: 'Apache/Nginx setup files',
        projectTypes: ['website', 'api'],
        fileExtension: '.zip'
      },
      'optimized': {
        name: 'Optimized Build',
        icon: 'speed',
        description: 'Minified and bundled for production',
        projectTypes: ['website'],
        fileExtension: '.zip'
      },
      
      // Mobile app formats
      'android-apk': {
        name: 'Android APK',
        icon: 'android',
        description: 'Installable Android package',
        projectTypes: ['mobileApp'],
        fileExtension: '.apk'
      },
      'ios-ipa': {
        name: 'iOS IPA',
        icon: 'apple',
        description: 'iOS application package',
        projectTypes: ['mobileApp'],
        fileExtension: '.ipa'
      },
      'app-store': {
        name: 'App Store Package',
        icon: 'store',
        description: 'Prepared for app store submission',
        projectTypes: ['mobileApp'],
        fileExtension: '.zip'
      },
      
      // Data visualization formats
      'static-image': {
        name: 'Static Image',
        icon: 'image',
        description: 'High-resolution PNG/SVG export',
        projectTypes: ['dataViz'],
        fileExtension: '.zip'
      },
      'interactive': {
        name: 'Interactive Web Version',
        icon: 'touch_app',
        description: 'Self-contained interactive HTML/JS/CSS',
        projectTypes: ['dataViz'],
        fileExtension: '.zip'
      },
      'embed': {
        name: 'Embed Code',
        icon: 'code',
        description: 'Code snippet for embedding in websites',
        projectTypes: ['dataViz'],
        fileExtension: '.html'
      },
      'data-export': {
        name: 'Data Export',
        icon: 'table_chart',
        description: 'Raw data in CSV/JSON format',
        projectTypes: ['dataViz'],
        fileExtension: '.zip'
      },
      
      // Document formats
      'pdf': {
        name: 'PDF Document',
        icon: 'picture_as_pdf',
        description: 'Portable Document Format',
        projectTypes: ['document'],
        fileExtension: '.pdf'
      },
      'epub': {
        name: 'EPUB/MOBI',
        icon: 'auto_stories',
        description: 'E-book formats for digital readers',
        projectTypes: ['document'],
        fileExtension: '.zip'
      },
      'print': {
        name: 'Print-Ready PDF',
        icon: 'print',
        description: 'PDF with bleed, crop marks for printing',
        projectTypes: ['document'],
        fileExtension: '.pdf'
      },
      'web': {
        name: 'Web Version',
        icon: 'language',
        description: 'HTML version for online publishing',
        projectTypes: ['document'],
        fileExtension: '.zip'
      },
      
      // API formats
      'docker': {
        name: 'Docker Container',
        icon: 'inventory_2',
        description: 'Containerized application with Docker',
        projectTypes: ['api'],
        fileExtension: '.tar'
      },
      'serverless': {
        name: 'Serverless Package',
        icon: 'cloud',
        description: 'AWS Lambda/Azure Functions package',
        projectTypes: ['api'],
        fileExtension: '.zip'
      },
      'documentation': {
        name: 'API Documentation',
        icon: 'menu_book',
        description: 'Swagger/OpenAPI documentation',
        projectTypes: ['api', 'code'],
        fileExtension: '.zip'
      },
      
      // Code formats
      'executable': {
        name: 'Executable',
        icon: 'terminal',
        description: 'Compiled executable program',
        projectTypes: ['code'],
        fileExtension: '.zip'
      },
      'library': {
        name: 'Library Package',
        icon: 'inventory',
        description: 'Packaged library for import',
        projectTypes: ['code'],
        fileExtension: '.zip'
      }
    };
    
    // Initialize
    this.init();
  }
  
  /**
   * Initialize the export system
   */
  init() {
    // Get DOM elements
    this.container = document.getElementById(this.config.containerId);
    this.overlay = document.getElementById(this.config.overlayId);
    this.progressContainer = document.getElementById(this.config.progressId);
    this.successContainer = document.getElementById(this.config.successId);
    this.closeButton = document.getElementById(this.config.closeButtonId);
    this.nextButton = document.getElementById(this.config.nextButtonId);
    this.backButton = document.getElementById(this.config.backButtonId);
    
    // Create elements if they don't exist
    if (!this.container) {
      this.createWizardInterface();
    }
    
    // Attach event listeners
    this.attachEventListeners();
    
    // Listen for content updates
    document.addEventListener('lumina:codeChanged', (e) => {
      const { html, css, js, assets } = e.detail;
      
      if (html !== undefined) this.state.currentContent.html = html;
      if (css !== undefined) this.state.currentContent.css = css;
      if (js !== undefined) this.state.currentContent.js = js;
      if (assets !== undefined) this.state.currentContent.assets = assets;
      
      // Auto-detect project type if enabled
      if (this.config.autoDetectProjectType) {
        this.detectProjectType();
      }
    });
  }
  
  /**
   * Create the wizard interface if it doesn't exist
   */
  createWizardInterface() {
    // Create overlay
    this.overlay = document.createElement('div');
    this.overlay.id = this.config.overlayId;
    this.overlay.className = 'overlay';
    this.overlay.style.display = 'none';
    document.body.appendChild(this.overlay);
    
    // Create wizard container
    this.container = document.createElement('div');
    this.container.id = this.config.containerId;
    this.container.className = 'export-wizard';
    this.container.style.display = 'none';
    document.body.appendChild(this.container);
    
    // Create progress container
    this.progressContainer = document.createElement('div');
    this.progressContainer.id = this.config.progressId;
    this.progressContainer.className = 'export-progress';
    this.progressContainer.style.display = 'none';
    document.body.appendChild(this.progressContainer);
    
    // Create success container
    this.successContainer = document.createElement('div');
    this.successContainer.id = this.config.successId;
    this.successContainer.className = 'export-success';
    this.successContainer.style.display = 'none';
    document.body.appendChild(this.successContainer);
    
    // Initialize wizard content
    this.renderWizardStep(1);
  }
  
  /**
   * Attach event listeners to UI controls
   */
  attachEventListeners() {
    // Close button
    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.closeWizard());
    }
    
    // Next button
    if (this.nextButton) {
      this.nextButton.addEventListener('click', () => this.nextStep());
    }
    
    // Back button
    if (this.backButton) {
      this.backButton.addEventListener('click', () => this.previousStep());
    }
    
    // Project type selection
    document.querySelectorAll(this.config.projectTypeSelector).forEach(option => {
      option.addEventListener('click', () => {
        // Remove selected class from all options
        document.querySelectorAll(this.config.projectTypeSelector).forEach(opt => {
          opt.classList.remove('selected');
        });
        
        // Add selected class to clicked option
        option.classList.add('selected');
        
        // Update state
        const projectTypeId = option.getAttribute('data-type');
        this.state.projectType = projectTypeId;
        
        // Update project name input if empty
        const projectNameInput = document.getElementById('project-name');
        if (projectNameInput && !projectNameInput.value) {
          projectNameInput.value = `My ${this.projectTypes[projectTypeId].name} Project`;
          this.state.projectName = projectNameInput.value;
        }
      });
    });
    
    // Project name input
    document.getElementById('project-name')?.addEventListener('input', (e) => {
      this.state.projectName = e.target.value;
    });
    
    // Project framework select
    document.getElementById('project-framework')?.addEventListener('change', (e) => {
      this.state.projectFramework = e.target.value;
    });
    
    // Listen for export button clicks
    document.addEventListener('click', (e) => {
      if (e.target.id === 'export-toggle' || e.target.closest('#export-toggle')) {
        this.openWizard();
      }
    });
  }
  
  /**
   * Open the export wizard
   */
  openWizard() {
    // Reset state
    this.state.currentStep = 1;
    this.state.exportProgress = 0;
    this.state.isExporting = false;
    this.state.exportResults = [];
    
    // Show overlay and wizard
    this.overlay.style.display = 'block';
    this.container.style.display = 'flex';
    this.progressContainer.style.display = 'none';
    this.successContainer.style.display = 'none';
    
    // Render first step
    this.renderWizardStep(1);
    
    // Auto-detect project type
    if (this.config.autoDetectProjectType) {
      this.detectProjectType();
    }
    
    // Dispatch event
    document.dispatchEvent(new CustomEvent('lumina:exportWizardOpened'));
  }
  
  /**
   * Close the export wizard
   */
  closeWizard() {
    this.overlay.style.display = 'none';
    this.container.style.display = 'none';
    this.progressContainer.style.display = 'none';
    this.successContainer.style.display = 'none';
    
    // Dispatch event
    document.dispatchEvent(new CustomEvent('lumina:exportWizardClosed'));
  }
  
  /**
   * Move to the next step in the wizard
   */
  nextStep() {
    // Validate current step
    if (!this.validateStep(this.state.currentStep)) {
      this.showValidationError();
      return;
    }
    
    // If on last step, start export
    if (this.state.currentStep === this.state.totalSteps) {
      this.startExport();
      return;
    }
    
    // Move to next step
    this.state.currentStep++;
    this.renderWizardStep(this.state.currentStep);
    
    // Update back button state
    this.backButton.disabled = false;
    
    // Update next button text on last step
    if (this.state.currentStep === this.state.totalSteps) {
      this.nextButton.innerHTML = `
        Export
        <span class="material-icons-round">download</span>
      `;
    } else {
      this.nextButton.innerHTML = `
        Next
        <span class="material-icons-round">arrow_forward</span>
      `;
    }
    
    // Dispatch event
    document.dispatchEvent(new CustomEvent('lumina:exportWizardStepChanged', {
      detail: { step: this.state.currentStep }
    }));
  }
  
  /**
   * Move to the previous step in the wizard
   */
  previousStep() {
    if (this.state.currentStep > 1) {
      this.state.currentStep--;
      this.renderWizardStep(this.state.currentStep);
      
      // Update back button state
      this.backButton.disabled = this.state.currentStep === 1;
      
      // Update next button text
      this.nextButton.innerHTML = `
        Next
        <span class="material-icons-round">arrow_forward</span>
      `;
      
      // Dispatch event
      document.dispatchEvent(new CustomEvent('lumina:exportWizardStepChanged', {
        detail: { step: this.state.currentStep }
      }));
    }
  }
  
  /**
   * Validate the current step
   * @param {number} step - Step number to validate
   * @returns {boolean} Whether the step is valid
   */
  validateStep(step) {
    switch (step) {
      case 1: // Project Type
        return this.state.projectType && this.state.projectName;
      case 2: // Export Goal
        return this.state.exportGoal;
      case 3: // Format Selection
        return this.state.selectedFormats.length > 0;
      case 4: // Customization
        return true; // All customization options are optional
      case 5: // Preview
        return true; // Preview is informational only
      default:
        return false;
    }
  }
  
  /**
   * Show validation error for the current step
   */
  showValidationError() {
    let errorMessage = 'Please complete all required fields before continuing.';
    
    switch (this.state.currentStep) {
      case 1:
        errorMessage = 'Please select a project type and enter a project name.';
        break;
      case 2:
        errorMessage = 'Please select an export goal.';
        break;
      case 3:
        errorMessage = 'Please select at least one export format.';
        break;
    }
    
    // Show error message
    this.showNotification(errorMessage, 'error');
  }
  
  /**
   * Render the specified wizard step
   * @param {number} step - Step number to render
   */
  renderWizardStep(step) {
    // Update active step in sidebar
    document.querySelectorAll('.wizard-step').forEach((stepEl, index) => {
      if (index + 1 === step) {
        stepEl.classList.add('active');
      } else {
        stepEl.classList.remove('active');
      }
      
      if (index + 1 < step) {
        stepEl.classList.add('completed');
      } else {
        stepEl.classList.remove('completed');
      }
    });
    
    // Get wizard main content container
    const wizardMain = document.querySelector('.wizard-main');
    if (!wizardMain) return;
    
    // Render step content
    switch (step) {
      case 1:
        wizardMain.innerHTML = this.renderProjectTypeStep();
        break;
      case 2:
        wizardMain.innerHTML = this.renderExportGoalStep();
        break;
      case 3:
        wizardMain.innerHTML = this.renderFormatSelectionStep();
        break;
      case 4:
        wizardMain.innerHTML = this.renderCustomizationStep();
        break;
      case 5:
        wizardMain.innerHTML = this.renderPreviewStep();
        break;
    }
    
    // Attach event listeners for the new content
    this.attachStepEventListeners(step);
  }
  
  /**
   * Render the project type selection step
   * @returns {string} HTML content
   */
  renderProjectTypeStep() {
    let projectTypeOptions = '';
    
    // Generate project type options
    Object.entries(this.projectTypes).forEach(([id, type]) => {
      const isSelected = this.state.projectType === id;
      projectTypeOptions += `
        <div class="project-type-option ${isSelected ? 'selected' : ''}" data-type="${id}">
          <div class="project-icon">
            <span class="material-icons-round">${type.icon}</span>
          </div>
          <div class="project-name">${type.name}</div>
          <div class="project-description">${type.description}</div>
        </div>
      `;
    });
    
    return `
      <div class="wizard-section">
        <h3>Select Project Type</h3>
        <p>Choose the type of project you're exporting. This will determine the available export formats and options.</p>
        
        <div class="project-type-options">
          ${projectTypeOptions}
        </div>
      </div>
      
      <div class="wizard-section">
        <h3>Project Details</h3>
        
        <div class="customization-options">
          <div class="customization-option">
            <label class="customization-label">Project Name</label>
            <input type="text" id="project-name" class="customization-input" value="${this.state.projectName}" placeholder="Enter project name">
          </div>
          
          <div class="customization-option">
            <label class="customization-label">Framework/Technology</label>
            <select id="project-framework" class="customization-select">
              ${this.renderFrameworkOptions()}
            </select>
          </div>
        </div>
      </div>
    `;
  }
  
  /**
   * Render framework options based on project type
   * @returns {string} HTML options
   */
  renderFrameworkOptions() {
    const projectType = this.state.projectType;
    let options = '';
    
    if (!projectType) {
      return '<option value="">Select a project type first</option>';
    }
    
    switch (projectType) {
      case 'website':
        options = `
          <option value="html" ${this.state.projectFramework === 'html' ? 'selected' : ''}>HTML/CSS/JavaScript</option>
          <option value="react" ${this.state.projectFramework === 'react' ? 'selected' : ''}>React</option>
          <option value="vue" ${this.state.projectFramework === 'vue' ? 'selected' : ''}>Vue.js</option>
          <option value="angular" ${this.state.projectFramework === 'angular' ? 'selected' : ''}>Angular</option>
          <option value="wordpress" ${this.state.projectFramework === 'wordpress' ? 'selected' : ''}>WordPress</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      case 'mobileApp':
        options = `
          <option value="react-native" ${this.state.projectFramework === 'react-native' ? 'selected' : ''}>React Native</option>
          <option value="flutter" ${this.state.projectFramework === 'flutter' ? 'selected' : ''}>Flutter</option>
          <option value="swift" ${this.state.projectFramework === 'swift' ? 'selected' : ''}>Swift (iOS)</option>
          <option value="kotlin" ${this.state.projectFramework === 'kotlin' ? 'selected' : ''}>Kotlin (Android)</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      case 'dataViz':
        options = `
          <option value="d3" ${this.state.projectFramework === 'd3' ? 'selected' : ''}>D3.js</option>
          <option value="chart-js" ${this.state.projectFramework === 'chart-js' ? 'selected' : ''}>Chart.js</option>
          <option value="tableau" ${this.state.projectFramework === 'tableau' ? 'selected' : ''}>Tableau</option>
          <option value="power-bi" ${this.state.projectFramework === 'power-bi' ? 'selected' : ''}>Power BI</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      case 'document':
        options = `
          <option value="markdown" ${this.state.projectFramework === 'markdown' ? 'selected' : ''}>Markdown</option>
          <option value="latex" ${this.state.projectFramework === 'latex' ? 'selected' : ''}>LaTeX</option>
          <option value="word" ${this.state.projectFramework === 'word' ? 'selected' : ''}>Microsoft Word</option>
          <option value="html" ${this.state.projectFramework === 'html' ? 'selected' : ''}>HTML</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      case 'api':
        options = `
          <option value="node" ${this.state.projectFramework === 'node' ? 'selected' : ''}>Node.js</option>
          <option value="python" ${this.state.projectFramework === 'python' ? 'selected' : ''}>Python</option>
          <option value="java" ${this.state.projectFramework === 'java' ? 'selected' : ''}>Java</option>
          <option value="go" ${this.state.projectFramework === 'go' ? 'selected' : ''}>Go</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      case 'code':
        options = `
          <option value="python" ${this.state.projectFramework === 'python' ? 'selected' : ''}>Python</option>
          <option value="javascript" ${this.state.projectFramework === 'javascript' ? 'selected' : ''}>JavaScript</option>
          <option value="java" ${this.state.projectFramework === 'java' ? 'selected' : ''}>Java</option>
          <option value="c-cpp" ${this.state.projectFramework === 'c-cpp' ? 'selected' : ''}>C/C++</option>
          <option value="other" ${this.state.projectFramework === 'other' ? 'selected' : ''}>Other</option>
        `;
        break;
      default:
        options = '<option value="">Select a framework</option>';
    }
    
    return options;
  }
  
  /**
   * Render the export goal selection step
   * @returns {string} HTML content
   */
  renderExportGoalStep() {
    let goalOptions = '';
    
    // Generate goal options
    Object.entries(this.exportGoals).forEach(([id, goal]) => {
      const isSelected = this.state.exportGoal === id;
      goalOptions += `
        <div class="export-goal-option ${isSelected ? 'selected' : ''}" data-goal="${id}">
          <div class="goal-icon">
            <span class="material-icons-round">${goal.icon}</span>
          </div>
          <div class="goal-details">
            <div class="goal-name">${goal.name}</div>
            <div class="goal-description">${goal.description}</div>
          </div>
        </div>
      `;
    });
    
    return `
      <div class="wizard-section">
        <h3>Select Export Goal</h3>
        <p>What do you plan to do with this export? This will help us recommend the most appropriate formats.</p>
        
        <div class="export-goal-options">
          ${goalOptions}
        </div>
      </div>
      
      <div class="wizard-section">
        <h3>Recommended Approach</h3>
        <p id="goal-recommendation">Select an export goal to see recommendations.</p>
      </div>
    `;
  }
  
  /**
   * Render the format selection step
   * @returns {string} HTML content
   */
  renderFormatSelectionStep() {
    if (!this.state.projectType) {
      return `
        <div class="wizard-section">
          <h3>Format Selection</h3>
          <p>Please go back and select a project type first.</p>
        </div>
      `;
    }
    
    // Get formats for the selected project type
    const projectType = this.state.projectType;
    const availableFormats = Object.entries(this.formatDefinitions)
      .filter(([id, format]) => format.projectTypes.includes(projectType))
      .map(([id, format]) => ({ id, ...format }));
    
    let formatOptions = '';
    
    // Generate format options
    availableFormats.forEach(format => {
      const isSelected = this.state.selectedFormats.includes(format.id);
      const isRecommended = this.isFormatRecommended(format.id);
      
      formatOptions += `
        <div class="format-option ${isSelected ? 'selected' : ''}" data-format="${format.id}">
          <div class="format-icon">
            <span class="material-icons-round">${format.icon}</span>
          </div>
          <div class="format-details">
            <div class="format-name">${format.name}</div>
            <div class="format-description">${format.description}</div>
          </div>
          ${isRecommended ? '<div class="format-badge">Recommended</div>' : ''}
        </div>
      `;
    });
    
    return `
      <div class="wizard-section">
        <h3>Select Export Formats</h3>
        <p>Choose one or more formats for your export. Recommended formats are based on your project type and export goal.</p>
        
        <div class="format-options">
          ${formatOptions}
        </div>
      </div>
    `;
  }
  
  /**
   * Render the customization step
   * @returns {string} HTML content
   */
  renderCustomizationStep() {
    if (!this.state.projectType || this.state.selectedFormats.length === 0) {
      return `
        <div class="wizard-section">
          <h3>Customization</h3>
          <p>Please go back and select a project type and export formats first.</p>
        </div>
      `;
    }
    
    // Get selected formats
    const selectedFormats = this.state.selectedFormats.map(id => ({
      id,
      ...this.formatDefinitions[id]
    }));
    
    // Generate customization options based on project type and selected formats
    let customizationSections = '';
    
    // Basic options
    customizationSections += `
      <div class="customization-section">
        <h4>Basic Options</h4>
        <div class="customization-options">
          <div class="customization-option">
            <label class="customization-label">Output Directory</label>
            <input type="text" id="output-directory" class="customization-input" value="${this.state.customOptions.outputDirectory || '/downloads'}" placeholder="Enter output directory">
          </div>
          
          <div class="customization-option">
            <label class="customization-label">Version</label>
            <input type="text" id="version" class="customization-input" value="${this.state.customOptions.version || '1.0.0'}" placeholder="Enter version number">
          </div>
        </div>
      </div>
    `;
    
    // Format-specific options
    if (this.state.projectType === 'website') {
      customizationSections += this.renderWebsiteCustomizationOptions(selectedFormats);
    } else if (this.state.projectType === 'mobileApp') {
      customizationSections += this.renderMobileAppCustomizationOptions(selectedFormats);
    } else if (this.state.projectType === 'dataViz') {
      customizationSections += this.renderDataVizCustomizationOptions(selectedFormats);
    } else if (this.state.projectType === 'document') {
      customizationSections += this.renderDocumentCustomizationOptions(selectedFormats);
    } else if (this.state.projectType === 'api') {
      customizationSections += this.renderApiCustomizationOptions(selectedFormats);
    } else if (this.state.projectType === 'code') {
      customizationSections += this.renderCodeCustomizationOptions(selectedFormats);
    }
    
    return `
      <div class="wizard-section">
        <h3>Customize Export</h3>
        <p>Configure options for your selected export formats. Default values are provided but can be modified as needed.</p>
        
        ${customizationSections}
      </div>
    `;
  }
  
  /**
   * Render website-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderWebsiteCustomizationOptions(selectedFormats) {
    let options = '';
    
    // Check if static site deployment is selected
    if (selectedFormats.some(format => format.id === 'static-site')) {
      options += `
        <div class="customization-section">
          <h4>Deployment Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Deployment Platform</label>
              <select id="deployment-platform" class="customization-select">
                <option value="netlify" ${this.state.customOptions.deploymentPlatform === 'netlify' ? 'selected' : ''}>Netlify</option>
                <option value="vercel" ${this.state.customOptions.deploymentPlatform === 'vercel' ? 'selected' : ''}>Vercel</option>
                <option value="github" ${this.state.customOptions.deploymentPlatform === 'github' ? 'selected' : ''}>GitHub Pages</option>
              </select>
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Domain Name (Optional)</label>
              <input type="text" id="domain-name" class="customization-input" value="${this.state.customOptions.domainName || ''}" placeholder="e.g., mywebsite.com">
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if optimized build is selected
    if (selectedFormats.some(format => format.id === 'optimized')) {
      options += `
        <div class="customization-section">
          <h4>Optimization Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="minify-html" class="checkbox-input" ${this.state.customOptions.minifyHtml ? 'checked' : ''}>
                <label for="minify-html" class="checkbox-label">Minify HTML</label>
              </div>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="minify-css" class="checkbox-input" ${this.state.customOptions.minifyCss ? 'checked' : ''}>
                <label for="minify-css" class="checkbox-label">Minify CSS</label>
              </div>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="minify-js" class="checkbox-input" ${this.state.customOptions.minifyJs ? 'checked' : ''}>
                <label for="minify-js" class="checkbox-label">Minify JavaScript</label>
              </div>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="optimize-images" class="checkbox-input" ${this.state.customOptions.optimizeImages ? 'checked' : ''}>
                <label for="optimize-images" class="checkbox-label">Optimize Images</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render mobile app-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderMobileAppCustomizationOptions(selectedFormats) {
    let options = '';
    
    // App information
    options += `
      <div class="customization-section">
        <h4>App Information</h4>
        <div class="customization-options">
          <div class="customization-option">
            <label class="customization-label">App Display Name</label>
            <input type="text" id="app-name" class="customization-input" value="${this.state.customOptions.appName || this.state.projectName}" placeholder="Enter app name">
          </div>
          
          <div class="customization-option">
            <label class="customization-label">Bundle Identifier</label>
            <input type="text" id="bundle-id" class="customization-input" value="${this.state.customOptions.bundleId || 'com.example.app'}" placeholder="e.g., com.example.app">
          </div>
        </div>
      </div>
    `;
    
    // Check if Android APK is selected
    if (selectedFormats.some(format => format.id === 'android-apk')) {
      options += `
        <div class="customization-section">
          <h4>Android Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Minimum SDK Version</label>
              <select id="android-min-sdk" class="customization-select">
                <option value="21" ${this.state.customOptions.androidMinSdk === '21' ? 'selected' : ''}>Android 5.0 (API 21)</option>
                <option value="23" ${this.state.customOptions.androidMinSdk === '23' ? 'selected' : ''}>Android 6.0 (API 23)</option>
                <option value="26" ${this.state.customOptions.androidMinSdk === '26' ? 'selected' : ''}>Android 8.0 (API 26)</option>
                <option value="29" ${this.state.customOptions.androidMinSdk === '29' ? 'selected' : ''}>Android 10.0 (API 29)</option>
                <option value="31" ${this.state.customOptions.androidMinSdk === '31' ? 'selected' : ''}>Android 12.0 (API 31)</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="android-signing" class="checkbox-input" ${this.state.customOptions.androidSigning ? 'checked' : ''}>
                <label for="android-signing" class="checkbox-label">Generate Signed APK</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if iOS IPA is selected
    if (selectedFormats.some(format => format.id === 'ios-ipa')) {
      options += `
        <div class="customization-section">
          <h4>iOS Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Minimum iOS Version</label>
              <select id="ios-min-version" class="customization-select">
                <option value="12.0" ${this.state.customOptions.iosMinVersion === '12.0' ? 'selected' : ''}>iOS 12.0</option>
                <option value="13.0" ${this.state.customOptions.iosMinVersion === '13.0' ? 'selected' : ''}>iOS 13.0</option>
                <option value="14.0" ${this.state.customOptions.iosMinVersion === '14.0' ? 'selected' : ''}>iOS 14.0</option>
                <option value="15.0" ${this.state.customOptions.iosMinVersion === '15.0' ? 'selected' : ''}>iOS 15.0</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="ios-testflight" class="checkbox-input" ${this.state.customOptions.iosTestflight ? 'checked' : ''}>
                <label for="ios-testflight" class="checkbox-label">Prepare for TestFlight</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render data visualization-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderDataVizCustomizationOptions(selectedFormats) {
    let options = '';
    
    // Check if static image is selected
    if (selectedFormats.some(format => format.id === 'static-image')) {
      options += `
        <div class="customization-section">
          <h4>Image Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Image Format</label>
              <select id="image-format" class="customization-select">
                <option value="png" ${this.state.customOptions.imageFormat === 'png' ? 'selected' : ''}>PNG</option>
                <option value="svg" ${this.state.customOptions.imageFormat === 'svg' ? 'selected' : ''}>SVG</option>
                <option value="jpg" ${this.state.customOptions.imageFormat === 'jpg' ? 'selected' : ''}>JPEG</option>
              </select>
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Resolution (DPI)</label>
              <select id="image-resolution" class="customization-select">
                <option value="72" ${this.state.customOptions.imageResolution === '72' ? 'selected' : ''}>72 DPI (Screen)</option>
                <option value="150" ${this.state.customOptions.imageResolution === '150' ? 'selected' : ''}>150 DPI (Medium)</option>
                <option value="300" ${this.state.customOptions.imageResolution === '300' ? 'selected' : ''}>300 DPI (Print)</option>
              </select>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if interactive is selected
    if (selectedFormats.some(format => format.id === 'interactive')) {
      options += `
        <div class="customization-section">
          <h4>Interactive Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-controls" class="checkbox-input" ${this.state.customOptions.includeControls ? 'checked' : ''}>
                <label for="include-controls" class="checkbox-label">Include Interactive Controls</label>
              </div>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="responsive-viz" class="checkbox-input" ${this.state.customOptions.responsiveViz ? 'checked' : ''}>
                <label for="responsive-viz" class="checkbox-label">Make Responsive</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if data export is selected
    if (selectedFormats.some(format => format.id === 'data-export')) {
      options += `
        <div class="customization-section">
          <h4>Data Export Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Data Format</label>
              <select id="data-format" class="customization-select">
                <option value="csv" ${this.state.customOptions.dataFormat === 'csv' ? 'selected' : ''}>CSV</option>
                <option value="json" ${this.state.customOptions.dataFormat === 'json' ? 'selected' : ''}>JSON</option>
                <option value="excel" ${this.state.customOptions.dataFormat === 'excel' ? 'selected' : ''}>Excel</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-metadata" class="checkbox-input" ${this.state.customOptions.includeMetadata ? 'checked' : ''}>
                <label for="include-metadata" class="checkbox-label">Include Metadata</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render document-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderDocumentCustomizationOptions(selectedFormats) {
    let options = '';
    
    // Check if PDF is selected
    if (selectedFormats.some(format => format.id === 'pdf')) {
      options += `
        <div class="customization-section">
          <h4>PDF Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Page Size</label>
              <select id="page-size" class="customization-select">
                <option value="a4" ${this.state.customOptions.pageSize === 'a4' ? 'selected' : ''}>A4</option>
                <option value="letter" ${this.state.customOptions.pageSize === 'letter' ? 'selected' : ''}>Letter</option>
                <option value="legal" ${this.state.customOptions.pageSize === 'legal' ? 'selected' : ''}>Legal</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-toc" class="checkbox-input" ${this.state.customOptions.includeToc ? 'checked' : ''}>
                <label for="include-toc" class="checkbox-label">Include Table of Contents</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if EPUB is selected
    if (selectedFormats.some(format => format.id === 'epub')) {
      options += `
        <div class="customization-section">
          <h4>E-book Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">E-book Format</label>
              <select id="ebook-format" class="customization-select">
                <option value="epub" ${this.state.customOptions.ebookFormat === 'epub' ? 'selected' : ''}>EPUB</option>
                <option value="mobi" ${this.state.customOptions.ebookFormat === 'mobi' ? 'selected' : ''}>MOBI (Kindle)</option>
                <option value="both" ${this.state.customOptions.ebookFormat === 'both' ? 'selected' : ''}>Both Formats</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-cover" class="checkbox-input" ${this.state.customOptions.includeCover ? 'checked' : ''}>
                <label for="include-cover" class="checkbox-label">Generate Cover Image</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render API-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderApiCustomizationOptions(selectedFormats) {
    let options = '';
    
    // Check if Docker is selected
    if (selectedFormats.some(format => format.id === 'docker')) {
      options += `
        <div class="customization-section">
          <h4>Docker Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Base Image</label>
              <select id="docker-base" class="customization-select">
                <option value="node" ${this.state.customOptions.dockerBase === 'node' ? 'selected' : ''}>Node.js</option>
                <option value="python" ${this.state.customOptions.dockerBase === 'python' ? 'selected' : ''}>Python</option>
                <option value="java" ${this.state.customOptions.dockerBase === 'java' ? 'selected' : ''}>Java</option>
                <option value="go" ${this.state.customOptions.dockerBase === 'go' ? 'selected' : ''}>Go</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-compose" class="checkbox-input" ${this.state.customOptions.includeCompose ? 'checked' : ''}>
                <label for="include-compose" class="checkbox-label">Include Docker Compose</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if documentation is selected
    if (selectedFormats.some(format => format.id === 'documentation')) {
      options += `
        <div class="customization-section">
          <h4>Documentation Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Documentation Format</label>
              <select id="doc-format" class="customization-select">
                <option value="swagger" ${this.state.customOptions.docFormat === 'swagger' ? 'selected' : ''}>Swagger/OpenAPI</option>
                <option value="postman" ${this.state.customOptions.docFormat === 'postman' ? 'selected' : ''}>Postman Collection</option>
                <option value="markdown" ${this.state.customOptions.docFormat === 'markdown' ? 'selected' : ''}>Markdown</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-examples" class="checkbox-input" ${this.state.customOptions.includeExamples ? 'checked' : ''}>
                <label for="include-examples" class="checkbox-label">Include Example Requests</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render code-specific customization options
   * @param {Array} selectedFormats - Selected format objects
   * @returns {string} HTML content
   */
  renderCodeCustomizationOptions(selectedFormats) {
    let options = '';
    
    // Check if library is selected
    if (selectedFormats.some(format => format.id === 'library')) {
      options += `
        <div class="customization-section">
          <h4>Library Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Package Manager</label>
              <select id="package-manager" class="customization-select">
                <option value="npm" ${this.state.customOptions.packageManager === 'npm' ? 'selected' : ''}>npm (Node.js)</option>
                <option value="pip" ${this.state.customOptions.packageManager === 'pip' ? 'selected' : ''}>pip (Python)</option>
                <option value="maven" ${this.state.customOptions.packageManager === 'maven' ? 'selected' : ''}>Maven (Java)</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-tests" class="checkbox-input" ${this.state.customOptions.includeTests ? 'checked' : ''}>
                <label for="include-tests" class="checkbox-label">Include Tests</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    // Check if executable is selected
    if (selectedFormats.some(format => format.id === 'executable')) {
      options += `
        <div class="customization-section">
          <h4>Executable Options</h4>
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Target Platform</label>
              <select id="target-platform" class="customization-select">
                <option value="windows" ${this.state.customOptions.targetPlatform === 'windows' ? 'selected' : ''}>Windows</option>
                <option value="macos" ${this.state.customOptions.targetPlatform === 'macos' ? 'selected' : ''}>macOS</option>
                <option value="linux" ${this.state.customOptions.targetPlatform === 'linux' ? 'selected' : ''}>Linux</option>
                <option value="all" ${this.state.customOptions.targetPlatform === 'all' ? 'selected' : ''}>All Platforms</option>
              </select>
            </div>
            
            <div class="customization-option">
              <div class="customization-checkbox">
                <input type="checkbox" id="include-installer" class="checkbox-input" ${this.state.customOptions.includeInstaller ? 'checked' : ''}>
                <label for="include-installer" class="checkbox-label">Generate Installer</label>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    return options;
  }
  
  /**
   * Render the preview step
   * @returns {string} HTML content
   */
  renderPreviewStep() {
    if (!this.state.projectType || this.state.selectedFormats.length === 0) {
      return `
        <div class="wizard-section">
          <h3>Preview</h3>
          <p>Please go back and select a project type and export formats first.</p>
        </div>
      `;
    }
    
    // Get selected formats
    const selectedFormats = this.state.selectedFormats.map(id => ({
      id,
      ...this.formatDefinitions[id]
    }));
    
    // Generate preview content
    let previewContent = '';
    selectedFormats.forEach(format => {
      const fileExtension = format.fileExtension || '.zip';
      const fileName = `${this.state.projectName.replace(/\s+/g, '-').toLowerCase()}${fileExtension}`;
      const filePath = `${this.state.customOptions.outputDirectory || '/downloads'}/${fileName}`;
      
      previewContent += `${format.name}: ${filePath}\n`;
    });
    
    // Generate estimated size
    const estimatedSize = this.estimateExportSize();
    
    return `
      <div class="wizard-section preview-section">
        <h3>Export Preview</h3>
        <p>Review your export package before proceeding. The following files will be generated:</p>
        
        <div class="preview-container">
          <div class="preview-header">
            <div class="preview-title">Export Package Contents</div>
            <div class="preview-controls">
              <button class="icon-button" title="Copy">
                <span class="material-icons-round">content_copy</span>
              </button>
            </div>
          </div>
          <div class="preview-content">
            ${previewContent}
          </div>
          <div class="preview-info">
            <div class="preview-size">
              <span class="material-icons-round">storage</span>
              Estimated size: ${estimatedSize}
            </div>
            <div class="preview-compatibility">
              <span class="material-icons-round compatibility-icon">check_circle</span>
              Compatible with selected project type
            </div>
          </div>
        </div>
        
        <p>Click "Export" to generate these files. The process may take a few moments depending on the complexity of your project.</p>
      </div>
    `;
  }
  
  /**
   * Attach event listeners for the current step
   * @param {number} step - Current step number
   */
  attachStepEventListeners(step) {
    switch (step) {
      case 1: // Project Type
        // Project type selection
        document.querySelectorAll('.project-type-option').forEach(option => {
          option.addEventListener('click', () => {
            // Remove selected class from all options
            document.querySelectorAll('.project-type-option').forEach(opt => {
              opt.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            option.classList.add('selected');
            
            // Update state
            const projectTypeId = option.getAttribute('data-type');
            this.state.projectType = projectTypeId;
            
            // Update project name input if empty
            const projectNameInput = document.getElementById('project-name');
            if (projectNameInput && !projectNameInput.value) {
              projectNameInput.value = `My ${this.projectTypes[projectTypeId].name} Project`;
              this.state.projectName = projectNameInput.value;
            }
            
            // Update framework options
            const frameworkSelect = document.getElementById('project-framework');
            if (frameworkSelect) {
              frameworkSelect.innerHTML = this.renderFrameworkOptions();
              this.state.projectFramework = frameworkSelect.value;
            }
          });
        });
        
        // Project name input
        document.getElementById('project-name')?.addEventListener('input', (e) => {
          this.state.projectName = e.target.value;
        });
        
        // Project framework select
        document.getElementById('project-framework')?.addEventListener('change', (e) => {
          this.state.projectFramework = e.target.value;
        });
        break;
        
      case 2: // Export Goal
        // Export goal selection
        document.querySelectorAll('.export-goal-option').forEach(option => {
          option.addEventListener('click', () => {
            // Remove selected class from all options
            document.querySelectorAll('.export-goal-option').forEach(opt => {
              opt.classList.remove('selected');
            });
            
            // Add selected class to clicked option
            option.classList.add('selected');
            
            // Update state
            const goalId = option.getAttribute('data-goal');
            this.state.exportGoal = goalId;
            
            // Update recommendation text
            const recommendationEl = document.getElementById('goal-recommendation');
            if (recommendationEl) {
              recommendationEl.textContent = this.getGoalRecommendation(goalId);
            }
          });
        });
        break;
        
      case 3: // Format Selection
        // Format selection
        document.querySelectorAll('.format-option').forEach(option => {
          option.addEventListener('click', () => {
            // Toggle selected class
            option.classList.toggle('selected');
            
            // Update state
            const formatId = option.getAttribute('data-format');
            if (option.classList.contains('selected')) {
              if (!this.state.selectedFormats.includes(formatId)) {
                this.state.selectedFormats.push(formatId);
              }
            } else {
              this.state.selectedFormats = this.state.selectedFormats.filter(id => id !== formatId);
            }
          });
        });
        break;
        
      case 4: // Customization
        // Output directory input
        document.getElementById('output-directory')?.addEventListener('input', (e) => {
          this.state.customOptions.outputDirectory = e.target.value;
        });
        
        // Version input
        document.getElementById('version')?.addEventListener('input', (e) => {
          this.state.customOptions.version = e.target.value;
        });
        
        // Website-specific options
        if (this.state.projectType === 'website') {
          // Deployment platform select
          document.getElementById('deployment-platform')?.addEventListener('change', (e) => {
            this.state.customOptions.deploymentPlatform = e.target.value;
          });
          
          // Domain name input
          document.getElementById('domain-name')?.addEventListener('input', (e) => {
            this.state.customOptions.domainName = e.target.value;
          });
          
          // Minify HTML checkbox
          document.getElementById('minify-html')?.addEventListener('change', (e) => {
            this.state.customOptions.minifyHtml = e.target.checked;
          });
          
          // Minify CSS checkbox
          document.getElementById('minify-css')?.addEventListener('change', (e) => {
            this.state.customOptions.minifyCss = e.target.checked;
          });
          
          // Minify JS checkbox
          document.getElementById('minify-js')?.addEventListener('change', (e) => {
            this.state.customOptions.minifyJs = e.target.checked;
          });
          
          // Optimize images checkbox
          document.getElementById('optimize-images')?.addEventListener('change', (e) => {
            this.state.customOptions.optimizeImages = e.target.checked;
          });
        }
        
        // Mobile app-specific options
        if (this.state.projectType === 'mobileApp') {
          // App name input
          document.getElementById('app-name')?.addEventListener('input', (e) => {
            this.state.customOptions.appName = e.target.value;
          });
          
          // Bundle ID input
          document.getElementById('bundle-id')?.addEventListener('input', (e) => {
            this.state.customOptions.bundleId = e.target.value;
          });
          
          // Android min SDK select
          document.getElementById('android-min-sdk')?.addEventListener('change', (e) => {
            this.state.customOptions.androidMinSdk = e.target.value;
          });
          
          // Android signing checkbox
          document.getElementById('android-signing')?.addEventListener('change', (e) => {
            this.state.customOptions.androidSigning = e.target.checked;
          });
          
          // iOS min version select
          document.getElementById('ios-min-version')?.addEventListener('change', (e) => {
            this.state.customOptions.iosMinVersion = e.target.value;
          });
          
          // iOS TestFlight checkbox
          document.getElementById('ios-testflight')?.addEventListener('change', (e) => {
            this.state.customOptions.iosTestflight = e.target.checked;
          });
        }
        
        // Data visualization-specific options
        if (this.state.projectType === 'dataViz') {
          // Image format select
          document.getElementById('image-format')?.addEventListener('change', (e) => {
            this.state.customOptions.imageFormat = e.target.value;
          });
          
          // Image resolution select
          document.getElementById('image-resolution')?.addEventListener('change', (e) => {
            this.state.customOptions.imageResolution = e.target.value;
          });
          
          // Include controls checkbox
          document.getElementById('include-controls')?.addEventListener('change', (e) => {
            this.state.customOptions.includeControls = e.target.checked;
          });
          
          // Responsive visualization checkbox
          document.getElementById('responsive-viz')?.addEventListener('change', (e) => {
            this.state.customOptions.responsiveViz = e.target.checked;
          });
          
          // Data format select
          document.getElementById('data-format')?.addEventListener('change', (e) => {
            this.state.customOptions.dataFormat = e.target.value;
          });
          
          // Include metadata checkbox
          document.getElementById('include-metadata')?.addEventListener('change', (e) => {
            this.state.customOptions.includeMetadata = e.target.checked;
          });
        }
        
        // Document-specific options
        if (this.state.projectType === 'document') {
          // Page size select
          document.getElementById('page-size')?.addEventListener('change', (e) => {
            this.state.customOptions.pageSize = e.target.value;
          });
          
          // Include TOC checkbox
          document.getElementById('include-toc')?.addEventListener('change', (e) => {
            this.state.customOptions.includeToc = e.target.checked;
          });
          
          // E-book format select
          document.getElementById('ebook-format')?.addEventListener('change', (e) => {
            this.state.customOptions.ebookFormat = e.target.value;
          });
          
          // Include cover checkbox
          document.getElementById('include-cover')?.addEventListener('change', (e) => {
            this.state.customOptions.includeCover = e.target.checked;
          });
        }
        
        // API-specific options
        if (this.state.projectType === 'api') {
          // Docker base select
          document.getElementById('docker-base')?.addEventListener('change', (e) => {
            this.state.customOptions.dockerBase = e.target.value;
          });
          
          // Include compose checkbox
          document.getElementById('include-compose')?.addEventListener('change', (e) => {
            this.state.customOptions.includeCompose = e.target.checked;
          });
          
          // Documentation format select
          document.getElementById('doc-format')?.addEventListener('change', (e) => {
            this.state.customOptions.docFormat = e.target.value;
          });
          
          // Include examples checkbox
          document.getElementById('include-examples')?.addEventListener('change', (e) => {
            this.state.customOptions.includeExamples = e.target.checked;
          });
        }
        
        // Code-specific options
        if (this.state.projectType === 'code') {
          // Package manager select
          document.getElementById('package-manager')?.addEventListener('change', (e) => {
            this.state.customOptions.packageManager = e.target.value;
          });
          
          // Include tests checkbox
          document.getElementById('include-tests')?.addEventListener('change', (e) => {
            this.state.customOptions.includeTests = e.target.checked;
          });
          
          // Target platform select
          document.getElementById('target-platform')?.addEventListener('change', (e) => {
            this.state.customOptions.targetPlatform = e.target.value;
          });
          
          // Include installer checkbox
          document.getElementById('include-installer')?.addEventListener('change', (e) => {
            this.state.customOptions.includeInstaller = e.target.checked;
          });
        }
        break;
        
      case 5: // Preview
        // No specific event listeners for preview step
        break;
    }
  }
  
  /**
   * Get recommendation text for export goal
   * @param {string} goalId - Export goal ID
   * @returns {string} Recommendation text
   */
  getGoalRecommendation(goalId) {
    if (!goalId) return 'Select an export goal to see recommendations.';
    
    switch (goalId) {
      case 'development':
        return 'For continued development, we recommend exporting the complete source code package with documentation. This will include all necessary files for further development in your preferred environment.';
      case 'testing':
        return 'For testing and review, we recommend exporting a deployable version that can be easily shared with testers. This may include a hosted preview URL or installable package depending on your project type.';
      case 'deployment':
        return 'For production deployment, we recommend optimized and minified builds with proper configuration for your target environment. This ensures the best performance and security for your users.';
      case 'presentation':
        return 'For presentation to stakeholders, we recommend exporting visual assets, documentation, and a simple demo version that highlights key features without requiring technical setup.';
      default:
        return 'Select an export goal to see recommendations.';
    }
  }
  
  /**
   * Check if a format is recommended for the current project type and export goal
   * @param {string} formatId - Format ID to check
   * @returns {boolean} Whether the format is recommended
   */
  isFormatRecommended(formatId) {
    if (!this.state.projectType || !this.state.exportGoal) return false;
    
    // Define recommended formats for each project type and export goal
    const recommendations = {
      website: {
        development: ['source'],
        testing: ['static-site'],
        deployment: ['optimized', 'static-site'],
        presentation: ['static-site']
      },
      mobileApp: {
        development: ['source'],
        testing: ['android-apk', 'ios-ipa'],
        deployment: ['app-store'],
        presentation: ['android-apk']
      },
      dataViz: {
        development: ['source', 'data-export'],
        testing: ['interactive'],
        deployment: ['interactive', 'embed'],
        presentation: ['static-image', 'interactive']
      },
      document: {
        development: ['source'],
        testing: ['pdf'],
        deployment: ['pdf', 'epub'],
        presentation: ['pdf']
      },
      api: {
        development: ['source', 'documentation'],
        testing: ['docker'],
        deployment: ['docker', 'serverless'],
        presentation: ['documentation']
      },
      code: {
        development: ['source'],
        testing: ['executable'],
        deployment: ['library', 'executable'],
        presentation: ['documentation']
      }
    };
    
    // Check if format is in recommendations
    return recommendations[this.state.projectType]?.[this.state.exportGoal]?.includes(formatId) || false;
  }
  
  /**
   * Estimate the size of the export package
   * @returns {string} Formatted size string
   */
  estimateExportSize() {
    if (!this.state.projectType || this.state.selectedFormats.length === 0) {
      return '0 KB';
    }
    
    // Base size by project type (in KB)
    const baseSizes = {
      website: 500,
      mobileApp: 5000,
      dataViz: 200,
      document: 100,
      api: 1000,
      code: 300
    };
    
    // Additional size by format (in KB)
    const formatSizes = {
      source: 1.5, // multiplier
      'static-site': 0.8, // multiplier
      deployment: 1.2, // multiplier
      optimized: 0.6, // multiplier
      'android-apk': 3000,
      'ios-ipa': 5000,
      'app-store': 8000,
      'static-image': 500,
      interactive: 800,
      embed: 200,
      'data-export': 300,
      pdf: 500,
      epub: 300,
      print: 800,
      web: 400,
      docker: 2000,
      serverless: 1500,
      documentation: 200,
      executable: 2000,
      library: 1000
    };
    
    // Calculate base size
    let totalSize = baseSizes[this.state.projectType] || 500;
    
    // Add size for each selected format
    this.state.selectedFormats.forEach(formatId => {
      if (formatId === 'source' || formatId === 'static-site' || formatId === 'deployment' || formatId === 'optimized') {
        // These are multipliers
        totalSize *= formatSizes[formatId] || 1;
      } else {
        // These are additions
        totalSize += formatSizes[formatId] || 0;
      }
    });
    
    // Format size
    if (totalSize < 1000) {
      return `${Math.round(totalSize)} KB`;
    } else if (totalSize < 1000000) {
      return `${(totalSize / 1000).toFixed(1)} MB`;
    } else {
      return `${(totalSize / 1000000).toFixed(1)} GB`;
    }
  }
  
  /**
   * Start the export process
   */
  startExport() {
    // Hide wizard and show progress
    this.container.style.display = 'none';
    this.progressContainer.style.display = 'block';
    
    // Update progress header
    const progressHeader = this.progressContainer.querySelector('.progress-header h3');
    if (progressHeader) {
      progressHeader.textContent = `Exporting ${this.state.projectName}`;
    }
    
    // Reset progress
    this.state.exportProgress = 0;
    this.state.isExporting = true;
    this.updateExportProgress(0);
    
    // Simulate export process
    this.simulateExport();
  }
  
  /**
   * Simulate the export process
   */
  simulateExport() {
    const steps = [
      { name: 'Collecting project files', weight: 0.2 },
      { name: 'Optimizing assets', weight: 0.3 },
      { name: 'Creating deployment package', weight: 0.3 },
      { name: 'Generating documentation', weight: 0.2 }
    ];
    
    let currentStep = 0;
    let currentProgress = 0;
    
    // Update progress steps
    this.updateProgressSteps(currentStep);
    
    // Simulate progress
    const progressInterval = setInterval(() => {
      if (!this.state.isExporting) {
        clearInterval(progressInterval);
        return;
      }
      
      currentProgress += 0.05;
      
      if (currentProgress >= 1) {
        currentProgress = 0;
        currentStep++;
        
        if (currentStep >= steps.length) {
          // Export complete
          clearInterval(progressInterval);
          this.completeExport();
          return;
        }
        
        // Update progress steps
        this.updateProgressSteps(currentStep);
      }
      
      // Calculate total progress
      let totalProgress = 0;
      for (let i = 0; i < currentStep; i++) {
        totalProgress += steps[i].weight;
      }
      totalProgress += steps[currentStep].weight * currentProgress;
      
      // Update progress bar
      this.updateExportProgress(totalProgress);
    }, 200);
  }
  
  /**
   * Update export progress
   * @param {number} progress - Progress value (0-1)
   */
  updateExportProgress(progress) {
    this.state.exportProgress = progress;
    
    // Update progress bar
    const progressBar = this.progressContainer.querySelector('.progress-bar');
    if (progressBar) {
      progressBar.style.width = `${progress * 100}%`;
    }
    
    // Update progress text
    const progressText = this.progressContainer.querySelector('.progress-details span:first-child');
    if (progressText) {
      progressText.textContent = `${Math.round(progress * 100)}% Complete`;
    }
    
    // Update estimated time
    const timeText = this.progressContainer.querySelector('.progress-details span:last-child');
    if (timeText) {
      const remainingSeconds = Math.round((1 - progress) * 60);
      timeText.textContent = `Estimated time: ${remainingSeconds} seconds`;
    }
  }
  
  /**
   * Update progress steps
   * @param {number} currentStep - Current step index
   */
  updateProgressSteps(currentStep) {
    const stepElements = this.progressContainer.querySelectorAll('.progress-step');
    if (!stepElements.length) return;
    
    stepElements.forEach((element, index) => {
      const statusElement = element.querySelector('.step-status');
      if (!statusElement) return;
      
      if (index < currentStep) {
        // Completed step
        statusElement.className = 'step-status completed';
        statusElement.innerHTML = '<span class="material-icons-round" style="font-size: 12px;">check</span>';
      } else if (index === currentStep) {
        // Current step
        statusElement.className = 'step-status in-progress';
        statusElement.innerHTML = '';
      } else {
        // Pending step
        statusElement.className = 'step-status pending';
        statusElement.innerHTML = '';
      }
    });
  }
  
  /**
   * Complete the export process
   */
  completeExport() {
    // Hide progress and show success
    this.progressContainer.style.display = 'none';
    this.successContainer.style.display = 'block';
    
    // Update success header
    const successHeader = this.successContainer.querySelector('.success-header h3');
    if (successHeader) {
      successHeader.textContent = `Export Completed Successfully`;
    }
    
    const successDescription = this.successContainer.querySelector('.success-header p');
    if (successDescription) {
      successDescription.textContent = `Your ${this.state.projectName} has been exported and is ready to use`;
    }
    
    // Generate export results
    this.generateExportResults();
    
    // Update success details
    this.updateSuccessDetails();
    
    // Attach event listeners to success buttons
    const doneButton = this.successContainer.querySelector('.success-action-button.primary');
    if (doneButton) {
      doneButton.addEventListener('click', () => this.closeWizard());
    }
    
    const exportAnotherButton = this.successContainer.querySelector('.success-action-button:not(.primary)');
    if (exportAnotherButton) {
      exportAnotherButton.addEventListener('click', () => {
        this.successContainer.style.display = 'none';
        this.container.style.display = 'flex';
        this.state.currentStep = 1;
        this.renderWizardStep(1);
      });
    }
    
    // Dispatch event
    document.dispatchEvent(new CustomEvent('lumina:exportCompleted', {
      detail: { results: this.state.exportResults }
    }));
  }
  
  /**
   * Generate export results
   */
  generateExportResults() {
    this.state.exportResults = [];
    
    // Get selected formats
    const selectedFormats = this.state.selectedFormats.map(id => ({
      id,
      ...this.formatDefinitions[id]
    }));
    
    // Generate results for each format
    selectedFormats.forEach(format => {
      const fileExtension = format.fileExtension || '.zip';
      const fileName = `${this.state.projectName.replace(/\s+/g, '-').toLowerCase()}${fileExtension}`;
      const filePath = `${this.state.customOptions.outputDirectory || '/downloads'}/${fileName}`;
      
      let result = {
        name: format.name,
        path: filePath,
        icon: format.icon,
        type: format.id
      };
      
      // Add deployment URL for deployable formats
      if (format.id === 'static-site') {
        const platform = this.state.customOptions.deploymentPlatform || 'netlify';
        const projectSlug = this.state.projectName.replace(/\s+/g, '-').toLowerCase();
        
        if (platform === 'netlify') {
          result.deploymentUrl = `https://${projectSlug}.netlify.app`;
        } else if (platform === 'vercel') {
          result.deploymentUrl = `https://${projectSlug}.vercel.app`;
        } else if (platform === 'github') {
          result.deploymentUrl = `https://${projectSlug}.github.io`;
        }
      }
      
      this.state.exportResults.push(result);
    });
    
    // Add documentation if applicable
    if (this.state.projectType !== 'document' && !this.state.selectedFormats.includes('documentation')) {
      this.state.exportResults.push({
        name: 'Documentation',
        path: `${this.state.customOptions.outputDirectory || '/downloads'}/${this.state.projectName.replace(/\s+/g, '-').toLowerCase()}-docs.pdf`,
        icon: 'description',
        type: 'documentation'
      });
    }
  }
  
  /**
   * Update success details with export results
   */
  updateSuccessDetails() {
    const successDetails = this.successContainer.querySelector('.success-details');
    if (!successDetails) return;
    
    let detailsHtml = '';
    
    this.state.exportResults.forEach(result => {
      let actionButtons = '';
      
      if (result.deploymentUrl) {
        actionButtons = `
          <button class="item-action-button" title="Open URL">
            <span class="material-icons-round">open_in_new</span>
          </button>
          <button class="item-action-button" title="Copy URL">
            <span class="material-icons-round">content_copy</span>
          </button>
        `;
      } else {
        actionButtons = `
          <button class="item-action-button" title="Download">
            <span class="material-icons-round">download</span>
          </button>
          <button class="item-action-button" title="Copy Path">
            <span class="material-icons-round">content_copy</span>
          </button>
        `;
      }
      
      detailsHtml += `
        <div class="export-item">
          <div class="export-item-icon">
            <span class="material-icons-round">${result.icon}</span>
          </div>
          <div class="export-item-details">
            <div class="export-item-name">${result.name}</div>
            <div class="export-item-path">${result.deploymentUrl || result.path}</div>
          </div>
          <div class="export-item-action">
            ${actionButtons}
          </div>
        </div>
      `;
    });
    
    successDetails.innerHTML = detailsHtml;
    
    // Attach event listeners to action buttons
    successDetails.querySelectorAll('.item-action-button').forEach(button => {
      button.addEventListener('click', (e) => {
        const action = button.getAttribute('title');
        const item = button.closest('.export-item');
        const path = item.querySelector('.export-item-path').textContent;
        
        if (action === 'Download') {
          this.showNotification(`Downloading ${path}...`);
        } else if (action === 'Copy Path' || action === 'Copy URL') {
          navigator.clipboard.writeText(path).then(() => {
            this.showNotification(`${action === 'Copy Path' ? 'Path' : 'URL'} copied to clipboard`);
          });
        } else if (action === 'Open URL') {
          window.open(path, '_blank');
        }
      });
    });
  }
  
  /**
   * Show notification message
   * @param {string} message - Message to display
   * @param {string} type - Notification type (info, success, error)
   */
  showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('export-notification');
    if (!notification) {
      notification = document.createElement('div');
      notification.id = 'export-notification';
      notification.style.position = 'fixed';
      notification.style.bottom = '20px';
      notification.style.right = '20px';
      notification.style.padding = '12px 16px';
      notification.style.borderRadius = '6px';
      notification.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
      notification.style.zIndex = '2000';
      notification.style.transition = 'opacity 0.3s, transform 0.3s';
      notification.style.opacity = '0';
      notification.style.transform = 'translateY(20px)';
      document.body.appendChild(notification);
    }
    
    // Set notification style based on type
    switch (type) {
      case 'success':
        notification.style.backgroundColor = '#10A37F';
        notification.style.color = 'white';
        break;
      case 'error':
        notification.style.backgroundColor = '#E53935';
        notification.style.color = 'white';
        break;
      default:
        notification.style.backgroundColor = '#202123';
        notification.style.color = '#ECECF1';
        notification.style.border = '1px solid #4D4D4F';
    }
    
    // Set message
    notification.textContent = message;
    
    // Show notification
    setTimeout(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateY(0)';
    }, 10);
    
    // Hide notification after delay
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transform = 'translateY(20px)';
      
      // Remove notification after animation
      setTimeout(() => {
        notification.remove();
      }, 300);
    }, 3000);
  }
  
  /**
   * Detect project type based on current content
   */
  detectProjectType() {
    if (this.state.projectType) return; // Already set
    
    const html = this.state.currentContent.html || '';
    const css = this.state.currentContent.css || '';
    const js = this.state.currentContent.js || '';
    
    // Check for website
    if (html.includes('<!DOCTYPE html>') || html.includes('<html') || html.includes('<body')) {
      this.state.projectType = 'website';
      
      // Select website option
      document.querySelectorAll('.project-type-option').forEach(option => {
        if (option.getAttribute('data-type') === 'website') {
          option.click();
        }
      });
      
      return;
    }
    
    // Check for mobile app
    if (js.includes('React Native') || js.includes('ReactNative') || js.includes('import { View, Text } from \'react-native\'')) {
      this.state.projectType = 'mobileApp';
      
      // Select mobile app option
      document.querySelectorAll('.project-type-option').forEach(option => {
        if (option.getAttribute('data-type') === 'mobileApp') {
          option.click();
        }
      });
      
      return;
    }
    
    // Check for data visualization
    if (js.includes('d3.') || js.includes('chart.js') || js.includes('Chart.') || html.includes('<canvas') || js.includes('plotly')) {
      this.state.projectType = 'dataViz';
      
      // Select data viz option
      document.querySelectorAll('.project-type-option').forEach(option => {
        if (option.getAttribute('data-type') === 'dataViz') {
          option.click();
        }
      });
      
      return;
    }
    
    // Check for document
    if (html.includes('# ') || html.includes('## ') || html.includes('### ') || 
        html.includes('<h1>') || html.includes('<h2>') || html.includes('<p>')) {
      this.state.projectType = 'document';
      
      // Select document option
      document.querySelectorAll('.project-type-option').forEach(option => {
        if (option.getAttribute('data-type') === 'document') {
          option.click();
        }
      });
      
      return;
    }
    
    // Check for API
    if (js.includes('app.get(') || js.includes('app.post(') || js.includes('router.') || 
        js.includes('express') || js.includes('http.createServer')) {
      this.state.projectType = 'api';
      
      // Select API option
      document.querySelectorAll('.project-type-option').forEach(option => {
        if (option.getAttribute('data-type') === 'api') {
          option.click();
        }
      });
      
      return;
    }
    
    // Default to code
    this.state.projectType = 'code';
    
    // Select code option
    document.querySelectorAll('.project-type-option').forEach(option => {
      if (option.getAttribute('data-type') === 'code') {
        option.click();
      }
    });
  }
  
  /**
   * Get current export state
   * @returns {Object} Current state
   */
  getState() {
    return { ...this.state };
  }
  
  /**
   * Set content directly
   * @param {Object} content - Content object with html, css, js, and assets properties
   */
  setContent(content) {
    if (content.html !== undefined) this.state.currentContent.html = content.html;
    if (content.css !== undefined) this.state.currentContent.css = content.css;
    if (content.js !== undefined) this.state.currentContent.js = content.js;
    if (content.assets !== undefined) this.state.currentContent.assets = content.assets;
    
    // Auto-detect project type if enabled
    if (this.config.autoDetectProjectType) {
      this.detectProjectType();
    }
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ExportSystem;
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
  // Create global instance if not already created
  if (!window.luminaExportSystem) {
    window.luminaExportSystem = new ExportSystem();
    
    // Log initialization
    console.log('Lumina AI Export System initialized');
  }
});
