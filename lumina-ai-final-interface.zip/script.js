// Lumina AI Interface Scripts

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
  // Toggle panels
  const memoryToggle = document.getElementById('memory-toggle');
  const memoryPanel = document.getElementById('memory-panel');
  
  const visualThinkingToggle = document.getElementById('visual-thinking-toggle');
  const visualThinkingPanel = document.getElementById('visual-thinking-panel');
  
  const operatorToggle = document.getElementById('operator-toggle');
  const operatorWindow = document.getElementById('operator-window');
  
  const testingToggle = document.getElementById('testing-toggle');
  const testingEnvironment = document.getElementById('testing-environment');
  
  const exportToggle = document.getElementById('export-toggle');
  const exportWizard = document.getElementById('export-wizard');
  const exportOverlay = document.getElementById('export-overlay');

  // Project group toggling
  const projectGroups = document.querySelectorAll('.project-group-header');
  projectGroups.forEach(header => {
    header.addEventListener('click', () => {
      const group = header.parentElement;
      group.classList.toggle('collapsed');
      const toggleIcon = header.querySelector('.toggle-icon');
      if (group.classList.contains('collapsed')) {
        toggleIcon.textContent = 'chevron_right';
      } else {
        toggleIcon.textContent = 'expand_more';
      }
    });
  });

  // Sidebar items
  const sidebarItems = document.querySelectorAll('.sidebar-item');
  sidebarItems.forEach(item => {
    item.addEventListener('click', () => {
      sidebarItems.forEach(i => i.classList.remove('active'));
      item.classList.add('active');
      
      // Update chat title
      const chatTitle = document.querySelector('.chat-title');
      if (chatTitle) {
        chatTitle.textContent = item.querySelector('.item-text').textContent;
      }
    });
  });

  // Memory panel toggle
  if (memoryToggle && memoryPanel) {
    memoryToggle.addEventListener('click', () => {
      memoryPanel.classList.toggle('active');
      memoryToggle.classList.toggle('active');
      
      // Close other panels
      visualThinkingPanel.classList.remove('active');
      visualThinkingToggle.classList.remove('active');
      operatorWindow.classList.remove('active');
      operatorToggle.classList.remove('active');
    });
    
    const closeMemoryPanel = memoryPanel.querySelector('.panel-action[title="Close"]');
    if (closeMemoryPanel) {
      closeMemoryPanel.addEventListener('click', () => {
        memoryPanel.classList.remove('active');
        memoryToggle.classList.remove('active');
      });
    }
  }

  // Visual thinking panel toggle
  if (visualThinkingToggle && visualThinkingPanel) {
    visualThinkingToggle.addEventListener('click', () => {
      visualThinkingPanel.classList.toggle('active');
      visualThinkingToggle.classList.toggle('active');
      
      // Close other panels
      memoryPanel.classList.remove('active');
      memoryToggle.classList.remove('active');
      operatorWindow.classList.remove('active');
      operatorToggle.classList.remove('active');
    });
    
    const closeVisualThinkingPanel = visualThinkingPanel.querySelector('.panel-action[title="Close"]');
    if (closeVisualThinkingPanel) {
      closeVisualThinkingPanel.addEventListener('click', () => {
        visualThinkingPanel.classList.remove('active');
        visualThinkingToggle.classList.remove('active');
      });
    }
  }

  // Operator window toggle
  if (operatorToggle && operatorWindow) {
    operatorToggle.addEventListener('click', () => {
      operatorWindow.classList.toggle('active');
      operatorToggle.classList.toggle('active');
      
      // Close other panels
      memoryPanel.classList.remove('active');
      memoryToggle.classList.remove('active');
      visualThinkingPanel.classList.remove('active');
      visualThinkingToggle.classList.remove('active');
    });
    
    const closeOperatorWindow = operatorWindow.querySelector('.operator-action[title="Close"]');
    if (closeOperatorWindow) {
      closeOperatorWindow.addEventListener('click', () => {
        operatorWindow.classList.remove('active');
        operatorToggle.classList.remove('active');
      });
    }
    
    const clearOperatorWindow = operatorWindow.querySelector('.operator-action[title="Clear"]');
    if (clearOperatorWindow) {
      clearOperatorWindow.addEventListener('click', () => {
        const operatorContent = operatorWindow.querySelector('.operator-content');
        if (operatorContent) {
          operatorContent.innerHTML = '';
        }
      });
    }
  }

  // Testing environment toggle
  if (testingToggle && testingEnvironment) {
    testingToggle.addEventListener('click', () => {
      testingEnvironment.classList.toggle('active');
      testingToggle.classList.toggle('active');
    });
    
    const closeTestingEnvironment = document.getElementById('close-testing');
    if (closeTestingEnvironment) {
      closeTestingEnvironment.addEventListener('click', () => {
        testingEnvironment.classList.remove('active');
        testingToggle.classList.remove('active');
      });
    }
  }

  // Export wizard toggle
  if (exportToggle && exportWizard && exportOverlay) {
    exportToggle.addEventListener('click', () => {
      exportWizard.style.display = 'flex';
      exportOverlay.style.display = 'block';
      exportToggle.classList.add('active');
      
      // Initialize wizard content
      initializeExportWizard();
    });
    
    const closeWizard = document.getElementById('close-wizard');
    if (closeWizard) {
      closeWizard.addEventListener('click', () => {
        exportWizard.style.display = 'none';
        exportOverlay.style.display = 'none';
        exportToggle.classList.remove('active');
      });
    }
    
    exportOverlay.addEventListener('click', () => {
      exportWizard.style.display = 'none';
      exportOverlay.style.display = 'none';
      exportToggle.classList.remove('active');
    });
  }

  // Code editor tabs
  const editorTabs = document.querySelectorAll('.editor-tab');
  const codeTextareas = document.querySelectorAll('.code-textarea');
  
  editorTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => {
      // Update active tab
      editorTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Show corresponding textarea
      codeTextareas.forEach(textarea => textarea.style.display = 'none');
      codeTextareas[index].style.display = 'block';
      
      // Update preview if needed
      updatePreview();
    });
  });

  // Initialize message input auto-resize
  const messageInput = document.querySelector('.message-input');
  if (messageInput) {
    messageInput.addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = (this.scrollHeight) + 'px';
      
      // Limit height
      if (parseInt(this.style.height) > 200) {
        this.style.height = '200px';
      }
    });
  }

  // Suggestion cards
  const suggestionCards = document.querySelectorAll('.suggestion-card');
  suggestionCards.forEach(card => {
    card.addEventListener('click', () => {
      if (messageInput) {
        messageInput.value = card.querySelector('h3').textContent;
        messageInput.focus();
        messageInput.dispatchEvent(new Event('input'));
      }
    });
  });

  // Initialize export wizard
  function initializeExportWizard() {
    const wizardMain = document.querySelector('.wizard-main');
    const wizardSteps = document.querySelectorAll('.wizard-step');
    const wizardBackButton = document.getElementById('wizard-back');
    const wizardNextButton = document.getElementById('wizard-next');
    
    let currentStep = 0;
    
    // Step content
    const stepContent = [
      // Step 1: Project Type
      `
        <div class="wizard-section">
          <h3>Select Project Type</h3>
          <p>Choose the type of project you want to export</p>
          
          <div class="project-type-options">
            <div class="project-type-option selected" data-type="website">
              <div class="project-icon">
                <span class="material-icons-round">language</span>
              </div>
              <div class="project-name">Website</div>
              <div class="project-description">HTML, CSS, and JavaScript</div>
            </div>
            
            <div class="project-type-option" data-type="mobile-app">
              <div class="project-icon">
                <span class="material-icons-round">smartphone</span>
              </div>
              <div class="project-name">Mobile App</div>
              <div class="project-description">React Native or Native code</div>
            </div>
            
            <div class="project-type-option" data-type="data-visualization">
              <div class="project-icon">
                <span class="material-icons-round">bar_chart</span>
              </div>
              <div class="project-name">Data Visualization</div>
              <div class="project-description">Charts, graphs, and dashboards</div>
            </div>
            
            <div class="project-type-option" data-type="document">
              <div class="project-icon">
                <span class="material-icons-round">description</span>
              </div>
              <div class="project-name">Document</div>
              <div class="project-description">Books, reports, and articles</div>
            </div>
          </div>
        </div>
      `,
      
      // Step 2: Export Goal
      `
        <div class="wizard-section">
          <h3>Select Export Goal</h3>
          <p>What do you want to do with your exported project?</p>
          
          <div class="export-goal-options">
            <div class="export-goal-option selected" data-goal="development">
              <div class="goal-icon">
                <span class="material-icons-round">code</span>
              </div>
              <div class="goal-details">
                <div class="goal-name">Continue Development</div>
                <div class="goal-description">Export source code and project files for further development</div>
              </div>
            </div>
            
            <div class="export-goal-option" data-goal="deployment">
              <div class="goal-icon">
                <span class="material-icons-round">cloud_upload</span>
              </div>
              <div class="goal-details">
                <div class="goal-name">Deploy to Production</div>
                <div class="goal-description">Prepare optimized files ready for deployment</div>
              </div>
            </div>
            
            <div class="export-goal-option" data-goal="sharing">
              <div class="goal-icon">
                <span class="material-icons-round">share</span>
              </div>
              <div class="goal-details">
                <div class="goal-name">Share with Others</div>
                <div class="goal-description">Create a package that's easy to share and demonstrate</div>
              </div>
            </div>
          </div>
        </div>
      `,
      
      // Step 3: Format
      `
        <div class="wizard-section">
          <h3>Select Export Format</h3>
          <p>Choose the format that best suits your needs</p>
          
          <div class="format-options">
            <div class="format-option selected" data-format="zip">
              <div class="format-icon">
                <span class="material-icons-round">folder_zip</span>
              </div>
              <div class="format-details">
                <div class="format-name">ZIP Archive</div>
                <div class="format-description">Complete project files compressed in a ZIP archive</div>
              </div>
              <div class="format-badge">Recommended</div>
            </div>
            
            <div class="format-option" data-format="github">
              <div class="format-icon">
                <span class="material-icons-round">integration_instructions</span>
              </div>
              <div class="format-details">
                <div class="format-name">GitHub Repository</div>
                <div class="format-description">Push to a new or existing GitHub repository</div>
              </div>
            </div>
            
            <div class="format-option" data-format="docker">
              <div class="format-icon">
                <span class="material-icons-round">view_in_ar</span>
              </div>
              <div class="format-details">
                <div class="format-name">Docker Container</div>
                <div class="format-description">Containerized application with all dependencies</div>
              </div>
            </div>
          </div>
        </div>
      `,
      
      // Step 4: Customize
      `
        <div class="wizard-section">
          <h3>Customize Export</h3>
          <p>Configure additional options for your export</p>
          
          <div class="customization-options">
            <div class="customization-option">
              <label class="customization-label">Project Name</label>
              <input type="text" class="customization-input" value="my-lumina-project" />
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Version</label>
              <input type="text" class="customization-input" value="1.0.0" />
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Author</label>
              <input type="text" class="customization-input" value="John Doe" />
            </div>
            
            <div class="customization-option">
              <label class="customization-label">License</label>
              <select class="customization-select">
                <option value="mit">MIT License</option>
                <option value="apache">Apache License 2.0</option>
                <option value="gpl">GNU GPL v3</option>
                <option value="proprietary">Proprietary</option>
              </select>
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Include</label>
              <div class="customization-checkbox">
                <input type="checkbox" id="include-source" class="checkbox-input" checked />
                <label for="include-source" class="checkbox-label">Source Code</label>
              </div>
              <div class="customization-checkbox">
                <input type="checkbox" id="include-assets" class="checkbox-input" checked />
                <label for="include-assets" class="checkbox-label">Assets</label>
              </div>
              <div class="customization-checkbox">
                <input type="checkbox" id="include-docs" class="checkbox-input" checked />
                <label for="include-docs" class="checkbox-label">Documentation</label>
              </div>
              <div class="customization-checkbox">
                <input type="checkbox" id="include-tests" class="checkbox-input" />
                <label for="include-tests" class="checkbox-label">Tests</label>
              </div>
            </div>
            
            <div class="customization-option">
              <label class="customization-label">Optimization</label>
              <div class="customization-checkbox">
                <input type="checkbox" id="minify-code" class="checkbox-input" checked />
                <label for="minify-code" class="checkbox-label">Minify Code</label>
              </div>
              <div class="customization-checkbox">
                <input type="checkbox" id="optimize-images" class="checkbox-input" checked />
                <label for="optimize-images" class="checkbox-label">Optimize Images</label>
              </div>
              <div class="customization-checkbox">
                <input type="checkbox" id="bundle-assets" class="checkbox-input" checked />
                <label for="bundle-assets" class="checkbox-label">Bundle Assets</label>
              </div>
            </div>
          </div>
        </div>
      `,
      
      // Step 5: Preview
      `
        <div class="wizard-section">
          <h3>Export Preview</h3>
          <p>Review your export configuration before proceeding</p>
          
          <div class="preview-section">
            <div class="preview-container">
              <div class="preview-header">
                <div class="preview-title">Project Structure</div>
                <div class="preview-controls">
                  <button class="icon-button">
                    <span class="material-icons-round">content_copy</span>
                  </button>
                </div>
              </div>
              <div class="preview-content">
my-lumina-project/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
├── assets/
│   ├── images/
│   └── fonts/
├── docs/
│   └── README.md
└── LICENSE
              </div>
              <div class="preview-info">
                <div class="preview-size">
                  <span class="material-icons-round">folder</span>
                  Estimated size: 2.4 MB
                </div>
                <div class="preview-compatibility">
                  <span class="material-icons-round compatibility-icon">check_circle</span>
                  Compatible with all modern browsers
                </div>
              </div>
            </div>
            
            <div class="mt-4">
              <h4 class="mb-4">Export Summary</h4>
              <div class="flex flex-col gap-2">
                <div class="flex justify-between">
                  <span class="text-secondary">Project Type:</span>
                  <span>Website</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-secondary">Export Goal:</span>
                  <span>Continue Development</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-secondary">Format:</span>
                  <span>ZIP Archive</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-secondary">Optimization:</span>
                  <span>Minify Code, Optimize Images, Bundle Assets</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      `
    ];
    
    // Initialize first step
    wizardMain.innerHTML = stepContent[currentStep];
    updateWizardSteps();
    
    // Project type selection
    wizardMain.addEventListener('click', (e) => {
      const projectTypeOption = e.target.closest('.project-type-option');
      if (projectTypeOption) {
        document.querySelectorAll('.project-type-option').forEach(opt => opt.classList.remove('selected'));
        projectTypeOption.classList.add('selected');
      }
      
      const exportGoalOption = e.target.closest('.export-goal-option');
      if (exportGoalOption) {
        document.querySelectorAll('.export-goal-option').forEach(opt => opt.classList.remove('selected'));
        exportGoalOption.classList.add('selected');
      }
      
      const formatOption = e.target.closest('.format-option');
      if (formatOption) {
        document.querySelectorAll('.format-option').forEach(opt => opt.classList.remove('selected'));
        formatOption.classList.add('selected');
      }
    });
    
    // Next button
    wizardNextButton.addEventListener('click', () => {
      if (currentStep < stepContent.length - 1) {
        currentStep++;
        wizardMain.innerHTML = stepContent[currentStep];
        updateWizardSteps();
      } else {
        // Final step - start export
        startExport();
      }
    });
    
    // Back button
    wizardBackButton.addEventListener('click', () => {
      if (currentStep > 0) {
        currentStep--;
        wizardMain.innerHTML = stepContent[currentStep];
        updateWizardSteps();
      }
    });
    
    // Update wizard steps
    function updateWizardSteps() {
      wizardSteps.forEach((step, index) => {
        if (index < currentStep) {
          step.classList.add('completed');
          step.classList.remove('active');
        } else if (index === currentStep) {
          step.classList.add('active');
          step.classList.remove('completed');
        } else {
          step.classList.remove('active', 'completed');
        }
      });
      
      // Update buttons
      wizardBackButton.disabled = currentStep === 0;
      if (currentStep === stepContent.length - 1) {
        wizardNextButton.textContent = 'Export';
      } else {
        wizardNextButton.innerHTML = 'Next <span class="material-icons-round">arrow_forward</span>';
      }
    }
    
    // Start export process
    function startExport() {
      // Hide wizard
      exportWizard.style.display = 'none';
      
      // Show progress
      const exportProgress = document.getElementById('export-progress');
      exportProgress.style.display = 'block';
      
      // Simulate progress
      const progressBar = exportProgress.querySelector('.progress-bar');
      const progressText = exportProgress.querySelector('.progress-details span:first-child');
      const progressSteps = exportProgress.querySelectorAll('.progress-step');
      
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 5;
        progressBar.style.width = `${progress}%`;
        progressText.textContent = `${progress}% Complete`;
        
        // Update steps
        if (progress >= 25) {
          progressSteps[0].querySelector('.step-status').className = 'step-status completed';
          progressSteps[0].querySelector('.step-status').innerHTML = '<span class="material-icons-round" style="font-size: 10px;">check</span>';
          progressSteps[1].querySelector('.step-status').className = 'step-status in-progress';
        }
        
        if (progress >= 50) {
          progressSteps[1].querySelector('.step-status').className = 'step-status completed';
          progressSteps[1].querySelector('.step-status').innerHTML = '<span class="material-icons-round" style="font-size: 10px;">check</span>';
          progressSteps[2].querySelector('.step-status').className = 'step-status in-progress';
        }
        
        if (progress >= 75) {
          progressSteps[2].querySelector('.step-status').className = 'step-status completed';
          progressSteps[2].querySelector('.step-status').innerHTML = '<span class="material-icons-round" style="font-size: 10px;">check</span>';
          progressSteps[3].querySelector('.step-status').className = 'step-status in-progress';
        }
        
        if (progress >= 100) {
          clearInterval(progressInterval);
          progressSteps[3].querySelector('.step-status').className = 'step-status completed';
          progressSteps[3].querySelector('.step-status').innerHTML = '<span class="material-icons-round" style="font-size: 10px;">check</span>';
          
          // Show success after a short delay
          setTimeout(() => {
            exportProgress.style.display = 'none';
            showExportSuccess();
          }, 500);
        }
      }, 100);
    }
    
    // Show export success
    function showExportSuccess() {
      const exportSuccess = document.getElementById('export-success');
      const successDetails = exportSuccess.querySelector('.success-details');
      
      // Populate success details
      successDetails.innerHTML = `
        <div class="export-item">
          <div class="export-item-icon">
            <span class="material-icons-round">folder_zip</span>
          </div>
          <div class="export-item-details">
            <div class="export-item-name">my-lumina-project.zip</div>
            <div class="export-item-path">/downloads/my-lumina-project.zip</div>
          </div>
          <div class="export-item-action">
            <button class="item-action-button" title="Download">
              <span class="material-icons-round">download</span>
            </button>
            <button class="item-action-button" title="Open">
              <span class="material-icons-round">open_in_new</span>
            </button>
          </div>
        </div>
        
        <div class="export-item">
          <div class="export-item-icon">
            <span class="material-icons-round">description</span>
          </div>
          <div class="export-item-details">
            <div class="export-item-name">README.md</div>
            <div class="export-item-path">/downloads/my-lumina-project/README.md</div>
          </div>
          <div class="export-item-action">
            <button class="item-action-button" title="View">
              <span class="material-icons-round">visibility</span>
            </button>
          </div>
        </div>
      `;
      
      // Show success
      exportSuccess.style.display = 'block';
      
      // Add event listeners
      const doneButton = exportSuccess.querySelector('.success-action-button.primary');
      if (doneButton) {
        doneButton.addEventListener('click', () => {
          exportSuccess.style.display = 'none';
          exportOverlay.style.display = 'none';
          exportToggle.classList.remove('active');
        });
      }
      
      const exportAnotherButton = exportSuccess.querySelector('.success-action-button:not(.primary)');
      if (exportAnotherButton) {
        exportAnotherButton.addEventListener('click', () => {
          exportSuccess.style.display = 'none';
          exportWizard.style.display = 'flex';
          initializeExportWizard();
        });
      }
    }
  }

  // Initialize testing environment
  initializeTestingEnvironment();
});

// Update preview in testing environment
function updatePreview() {
  const htmlEditor = document.querySelector('.html-editor');
  const cssEditor = document.querySelector('.css-editor');
  const jsEditor = document.querySelector('.js-editor');
  const previewFrame = document.getElementById('preview-frame');
  
  if (htmlEditor && cssEditor && jsEditor && previewFrame) {
    const html = htmlEditor.value;
    const css = cssEditor.value;
    const js = jsEditor.value;
    
    const previewContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>${css}</style>
      </head>
      <body>
        ${html}
        <script>${js}</script>
      </body>
      </html>
    `;
    
    const previewDocument = previewFrame.contentDocument || previewFrame.contentWindow.document;
    previewDocument.open();
    previewDocument.write(previewContent);
    previewDocument.close();
  }
}

// Initialize testing environment
function initializeTestingEnvironment() {
  // Sample HTML, CSS, and JS
  const sampleHTML = `<div class="container">
  <h1>Hello, Lumina AI!</h1>
  <p>This is a sample project created with Lumina AI.</p>
  <button id="demo-button">Click Me</button>
  <div id="result"></div>
</div>`;

  const sampleCSS = `.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  color: #10A37F;
}

button {
  background-color: #10A37F;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 20px;
}

button:hover {
  background-color: #0D8A6C;
}

#result {
  margin-top: 20px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  min-height: 20px;
}`;

  const sampleJS = `document.getElementById('demo-button').addEventListener('click', function() {
  const result = document.getElementById('result');
  result.textContent = 'Button clicked at ' + new Date().toLocaleTimeString();
});`;

  // Set sample code
  const htmlEditor = document.querySelector('.html-editor');
  const cssEditor = document.querySelector('.css-editor');
  const jsEditor = document.querySelector('.js-editor');
  
  if (htmlEditor) htmlEditor.value = sampleHTML;
  if (cssEditor) cssEditor.value = sampleCSS;
  if (jsEditor) jsEditor.value = sampleJS;
  
  // Initialize editors
  if (htmlEditor) {
    htmlEditor.addEventListener('input', updatePreview);
  }
  
  if (cssEditor) {
    cssEditor.addEventListener('input', updatePreview);
  }
  
  if (jsEditor) {
    jsEditor.addEventListener('input', updatePreview);
  }
  
  // Initial preview update
  updatePreview();
  
  // Device selector
  const deviceSelector = document.getElementById('device-selector');
  const previewFrame = document.getElementById('preview-frame');
  
  if (deviceSelector && previewFrame) {
    deviceSelector.addEventListener('click', () => {
      // Create device menu
      const deviceMenu = document.createElement('div');
      deviceMenu.className = 'device-menu';
      deviceMenu.innerHTML = `
        <div class="device-option" data-device="desktop">
          <span class="material-icons-round">desktop_windows</span>
          Desktop
        </div>
        <div class="device-option" data-device="tablet">
          <span class="material-icons-round">tablet</span>
          Tablet
        </div>
        <div class="device-option" data-device="mobile">
          <span class="material-icons-round">smartphone</span>
          Mobile
        </div>
      `;
      
      // Position menu
      const rect = deviceSelector.getBoundingClientRect();
      deviceMenu.style.position = 'absolute';
      deviceMenu.style.top = `${rect.bottom + 5}px`;
      deviceMenu.style.left = `${rect.left}px`;
      deviceMenu.style.zIndex = '1000';
      
      // Add to document
      document.body.appendChild(deviceMenu);
      
      // Add event listeners
      const deviceOptions = deviceMenu.querySelectorAll('.device-option');
      deviceOptions.forEach(option => {
        option.addEventListener('click', () => {
          const device = option.getAttribute('data-device');
          
          // Update preview frame size
          if (device === 'desktop') {
            previewFrame.style.width = '100%';
            previewFrame.style.height = '100%';
            deviceSelector.innerHTML = '<span class="material-icons-round">desktop_windows</span> Desktop <span class="material-icons-round">arrow_drop_down</span>';
          } else if (device === 'tablet') {
            previewFrame.style.width = '768px';
            previewFrame.style.height = '1024px';
            deviceSelector.innerHTML = '<span class="material-icons-round">tablet</span> Tablet <span class="material-icons-round">arrow_drop_down</span>';
          } else if (device === 'mobile') {
            previewFrame.style.width = '375px';
            previewFrame.style.height = '667px';
            deviceSelector.innerHTML = '<span class="material-icons-round">smartphone</span> Mobile <span class="material-icons-round">arrow_drop_down</span>';
          }
          
          // Remove menu
          document.body.removeChild(deviceMenu);
        });
      });
      
      // Close menu when clicking outside
      document.addEventListener('click', function closeMenu(e) {
        if (!deviceMenu.contains(e.target) && e.target !== deviceSelector) {
          if (document.body.contains(deviceMenu)) {
            document.body.removeChild(deviceMenu);
          }
          document.removeEventListener('click', closeMenu);
        }
      });
    });
  }
  
  // Refresh preview
  const refreshPreview = document.getElementById('refresh-preview');
  if (refreshPreview) {
    refreshPreview.addEventListener('click', updatePreview);
  }
  
  // Debug console
  const debugContent = document.getElementById('debug-content');
  if (debugContent && previewFrame) {
    // Override console.log in the preview
    previewFrame.addEventListener('load', () => {
      const previewConsole = previewFrame.contentWindow.console;
      
      previewFrame.contentWindow.console = {
        log: function() {
          previewConsole.log.apply(previewConsole, arguments);
          logToDebugPanel('log', arguments);
        },
        error: function() {
          previewConsole.error.apply(previewConsole, arguments);
          logToDebugPanel('error', arguments);
        },
        warn: function() {
          previewConsole.warn.apply(previewConsole, arguments);
          logToDebugPanel('warn', arguments);
        },
        info: function() {
          previewConsole.info.apply(previewConsole, arguments);
          logToDebugPanel('info', arguments);
        }
      };
      
      // Catch errors
      previewFrame.contentWindow.addEventListener('error', (e) => {
        logToDebugPanel('error', [`${e.message} at line ${e.lineno}:${e.colno}`]);
      });
    });
    
    // Log to debug panel
    function logToDebugPanel(type, args) {
      const logItem = document.createElement('div');
      logItem.className = `log-item log-${type}`;
      
      // Convert arguments to string
      let message = '';
      for (let i = 0; i < args.length; i++) {
        if (typeof args[i] === 'object') {
          try {
            message += JSON.stringify(args[i]) + ' ';
          } catch (e) {
            message += args[i] + ' ';
          }
        } else {
          message += args[i] + ' ';
        }
      }
      
      logItem.textContent = message;
      debugContent.appendChild(logItem);
      debugContent.scrollTop = debugContent.scrollHeight;
    }
    
    // Clear console
    const clearConsole = document.querySelector('.debug-action[title="Clear Console"]');
    if (clearConsole) {
      clearConsole.addEventListener('click', () => {
        debugContent.innerHTML = '';
      });
    }
  }
  
  // Screenshot button
  const screenshotButton = document.getElementById('screenshot-button');
  if (screenshotButton && previewFrame) {
    screenshotButton.addEventListener('click', () => {
      // Create canvas
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      // Set canvas size
      canvas.width = previewFrame.clientWidth;
      canvas.height = previewFrame.clientHeight;
      
      // Draw iframe content to canvas
      context.drawImage(previewFrame, 0, 0, canvas.width, canvas.height);
      
      // Convert to image
      const image = canvas.toDataURL('image/png');
      
      // Create download link
      const link = document.createElement('a');
      link.href = image;
      link.download = 'lumina-preview-screenshot.png';
      link.click();
    });
  }
  
  // Responsive view
  const responsiveView = document.getElementById('responsive-view');
  if (responsiveView && previewFrame) {
    responsiveView.addEventListener('click', () => {
      const previewContent = previewFrame.parentElement;
      previewContent.classList.toggle('responsive-mode');
      
      if (previewContent.classList.contains('responsive-mode')) {
        // Enable responsive mode
        previewFrame.style.width = '100%';
        previewFrame.style.height = '100%';
        previewContent.style.overflow = 'auto';
        responsiveView.classList.add('active');
      } else {
        // Disable responsive mode
        previewFrame.style.width = '100%';
        previewFrame.style.height = '100%';
        previewContent.style.overflow = 'hidden';
        responsiveView.classList.remove('active');
      }
    });
  }
}
