// Lumina AI Chat Interface - Interactive Features

document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message');
    const emptyState = document.getElementById('empty-state');
    const messagesContainer = document.getElementById('messages-container');
    const memoryToggle = document.getElementById('memory-toggle');
    const thinkingToggle = document.getElementById('thinking-toggle');
    const tasksToggle = document.getElementById('tasks-toggle');
    const memoryPanel = document.getElementById('memory-panel');
    const closeMemory = document.getElementById('close-memory');
    const suggestionCards = document.querySelectorAll('.suggestion-card');
    const acceptTaskButton = document.getElementById('accept-task');
    const modifyTaskButton = document.getElementById('modify-task');
    const dismissTaskButton = document.getElementById('dismiss-task');
    const voiceInputButton = document.getElementById('voice-input');
    const searchButton = document.getElementById('search-button');
    const deepResearchButton = document.getElementById('deep-research');
    
    // Initialize the interface
    initializeInterface();
    
    // Add event listeners
    addEventListeners();
    
    // Functions
    function initializeInterface() {
        // Focus on the message input
        messageInput.focus();
        
        // Show empty state by default
        emptyState.style.display = 'flex';
        messagesContainer.style.display = 'none';
    }
    
    function addEventListeners() {
        // Send message on button click
        if (sendButton) {
            sendButton.addEventListener('click', handleSendMessage);
        }
        
        // Send message on Enter key (without Shift)
        if (messageInput) {
            messageInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                }
            });
            
            // Auto-resize textarea
            messageInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
        }
        
        // Toggle memory panel
        if (memoryToggle) {
            memoryToggle.addEventListener('click', function() {
                memoryPanel.classList.toggle('active');
            });
        }
        
        // Close memory panel
        if (closeMemory) {
            closeMemory.addEventListener('click', function() {
                memoryPanel.classList.remove('active');
            });
        }
        
        // Toggle thinking display
        if (thinkingToggle) {
            thinkingToggle.addEventListener('click', function() {
                const thinkingDisplay = document.querySelector('.thinking-display');
                if (thinkingDisplay) {
                    thinkingDisplay.classList.toggle('hidden');
                } else {
                    showNotification('Visual thinking is not available for this conversation yet');
                }
            });
        }
        
        // Toggle tasks panel
        if (tasksToggle) {
            tasksToggle.addEventListener('click', function() {
                const taskStatus = document.querySelector('.task-status');
                if (taskStatus) {
                    taskStatus.classList.toggle('hidden');
                } else {
                    showNotification('No active tasks for this conversation');
                }
            });
        }
        
        // Handle suggestion cards
        if (suggestionCards) {
            suggestionCards.forEach(card => {
                card.addEventListener('click', function() {
                    const topic = card.querySelector('h3').textContent;
                    messageInput.value = `Help me with ${topic.toLowerCase()}`;
                    handleSendMessage();
                });
            });
        }
        
        // Handle task buttons
        if (acceptTaskButton) {
            acceptTaskButton.addEventListener('click', function() {
                const taskSuggestion = document.querySelector('.task-suggestion');
                if (taskSuggestion) {
                    taskSuggestion.classList.add('hidden');
                    showNotification('Task accepted and started');
                }
            });
        }
        
        if (modifyTaskButton) {
            modifyTaskButton.addEventListener('click', function() {
                showNotification('Task modification dialog would appear here');
            });
        }
        
        if (dismissTaskButton) {
            dismissTaskButton.addEventListener('click', function() {
                const taskSuggestion = document.querySelector('.task-suggestion');
                if (taskSuggestion) {
                    taskSuggestion.classList.add('hidden');
                    showNotification('Task suggestion dismissed');
                }
            });
        }
        
        // Handle voice input
        if (voiceInputButton) {
            voiceInputButton.addEventListener('click', function() {
                showNotification('Voice input activated');
                // Simulate voice input after a delay
                setTimeout(() => {
                    messageInput.value = 'Tell me more about renewable energy in emerging markets';
                    showNotification('Voice input captured');
                }, 2000);
            });
        }
        
        // Handle search button
        if (searchButton) {
            searchButton.addEventListener('click', function() {
                showNotification('Search activated');
                messageInput.value = 'Search: renewable energy trends';
                messageInput.focus();
            });
        }
        
        // Handle deep research button
        if (deepResearchButton) {
            deepResearchButton.addEventListener('click', function() {
                showNotification('Deep research mode activated');
                messageInput.value = 'Conduct deep research on renewable energy market growth';
                messageInput.focus();
            });
        }
    }
    
    function handleSendMessage() {
        const messageText = messageInput.value.trim();
        if (!messageText) return;
        
        // Hide empty state and show messages container
        emptyState.style.display = 'none';
        messagesContainer.style.display = 'block';
        
        // Create a new message group for the user message
        const messageGroup = document.createElement('div');
        messageGroup.className = 'message-group';
        
        // Create the user message
        const userMessage = document.createElement('div');
        userMessage.className = 'message user-message';
        userMessage.innerHTML = `
            <div class="message-content">
                <p>${messageText}</p>
            </div>
        `;
        
        // Add the user message to the group
        messageGroup.appendChild(userMessage);
        
        // Add the message group to the container
        messagesContainer.appendChild(messageGroup);
        
        // Clear the input
        messageInput.value = '';
        messageInput.style.height = 'auto';
        
        // Scroll to the bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Simulate assistant response after a delay
        setTimeout(() => {
            // Create a new message group for the assistant response
            const assistantGroup = document.createElement('div');
            assistantGroup.className = 'message-group';
            
            // Create the assistant message
            const assistantMessage = document.createElement('div');
            assistantMessage.className = 'message assistant-message';
            
            // Generate response based on user message
            const responseText = generateResponse(messageText);
            
            assistantMessage.innerHTML = `
                <div class="message-content">
                    <p>${responseText}</p>
                </div>
            `;
            
            // Add the assistant message to the group
            assistantGroup.appendChild(assistantMessage);
            
            // Add the message group to the container
            messagesContainer.appendChild(assistantGroup);
            
            // Scroll to the bottom
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // Update context indicator
            updateContextIndicator(10); // Increase by 10%
        }, 1000);
    }
    
    function generateResponse(userMessage) {
        // Simple response generation based on user message
        const lowerMessage = userMessage.toLowerCase();
        
        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return 'Hello! How can I help you today?';
        } else if (lowerMessage.includes('renewable energy')) {
            return 'Renewable energy is a rapidly growing sector globally. Would you like me to analyze specific trends or provide information about particular technologies like solar or wind power?';
        } else if (lowerMessage.includes('search:')) {
            return 'I\'ve searched for information on your query. Would you like me to compile the results into a structured report or provide a brief summary?';
        } else if (lowerMessage.includes('deep research')) {
            return 'I\'ll conduct comprehensive research on this topic, analyzing multiple sources and compiling detailed information. This may take a few moments. Would you like me to break this down into an autonomous task?';
        } else {
            return `I understand you're interested in "${userMessage}". How would you like me to help with this? I can provide information, create content, analyze data, or work on this as an autonomous task.`;
        }
    }
    
    function updateContextIndicator(increase) {
        const contextFill = document.querySelector('.context-fill');
        const contextText = document.querySelector('.context-text');
        
        if (contextFill && contextText) {
            // Get current width as percentage
            const currentWidth = parseFloat(contextFill.style.width) || 65;
            const newWidth = Math.min(currentWidth + increase, 100);
            
            // Update the fill width
            contextFill.style.width = `${newWidth}%`;
            
            // Update the text
            contextText.textContent = `Context: ${Math.round(newWidth)}% used`;
            
            // Change color based on percentage
            if (newWidth > 90) {
                contextFill.style.backgroundColor = '#E53935'; // Red
                showNotification('Warning: Context limit approaching');
            } else if (newWidth > 75) {
                contextFill.style.backgroundColor = '#FF9800'; // Orange
            }
        }
    }
    
    function showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        // Add to the DOM
        document.body.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => {
            notification.classList.add('active');
        }, 10);
        
        // Remove after delay
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // Add notification styles
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #202123;
            color: #ECECF1;
            padding: 12px 16px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.3s, transform 0.3s;
            font-size: 14px;
            border: 1px solid #4D4D4F;
        }
        
        .notification.active {
            opacity: 1;
            transform: translateY(0);
        }
    `;
    
    document.head.appendChild(style);
});
